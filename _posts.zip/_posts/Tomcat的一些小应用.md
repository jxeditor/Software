---
title: Tomcat的一些小应用
date: 2018-06-18 07:53:01
categories: 搭建
tags: 
    - tomcat
---

## 自动重新加载
```
# 修改tomcat/conf/context.xml文件
# 加上reloadable="true"
<Context reloadable="true">
```

<!-- more -->

---

## 开启manager
```
# 修改tomcat/conf/tomcat-users.xml文件
<role rolename="manager-gui"/>
<role rolename="admin-gui"/>
<role rolename="manager-script"/>
<user username="admin" password="admin" roles="admin-gui,manager-gui,manager-script"/>
```

## 设置Tomcat展开目录
```
# 打开Tomcat所在安装目录,打开到conf配置文件下,打开web.xml文件
# 修改listings属性,将其设定为true
<init-param>
    <param-name>listings</param-name>
    <param-value>false</param-value>
</init-param>
# 重启Tomcat服务
```