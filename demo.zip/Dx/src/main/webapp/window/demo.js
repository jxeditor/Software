$("#root").html("<select name='url' id='url' style='margin-right: 2.2em;'></select>")
FillUnit();
function FillUnit() {
    var url = "/mysql/selectUrlData";
    $.ajax({
        async: false,
        type: "get",
        url: url,
        dataType: "json",
        success: function (data) {
            var str = "<option value=''>---</option>";
            for (var i = 0; i < data.length; i++) {
                str += "<option value='" + data[i].id + "'>" + data[i].name + "</option>"
            }
            $("#url").html(str)
        },
        error: function () {
            alert('ERROR')
        }
    })
}