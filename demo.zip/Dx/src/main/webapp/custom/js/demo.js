$("#div1").html("<select name='news_type' id='news_type' style='width: 170px;margin-left: 2.2em;'></select>")
$("#div2").html("<select name='news_region' id='news_region' style='width: 170px;margin-left: 2.2em;'></select>")
FillType();
FillRegion();

function FillType() {
    var url = "/mysql/selectTypeData";
    $.ajax({
        async: false,
        type: "get",
        url: url,
        dataType: "json",
        success: function (data) {
            var str = "<option value='-1'>---</option>";
            for (var i = 0; i < data.length; i++) {
                str += "<option value='" + data[i].id + "'>" + data[i].name + "</option>"
            }
            $("#news_type").html(str)
        },
        error: function () {
            alert('ERROR')
        }
    })
}

function FillRegion() {
    var url = "/mysql/selectRegionData";
    $.ajax({
        async: false,
        type: "get",
        url: url,
        dataType: "json",
        success: function (data) {
            var str = "<option value='-1'>---</option>";
            for (var i = 0; i < data.length; i++) {
                str += "<option value='" + data[i].id + "'>" + data[i].name + "</option>"
            }
            $("#news_region").html(str)
        },
        error: function () {
            alert('ERROR')
        }
    })
}