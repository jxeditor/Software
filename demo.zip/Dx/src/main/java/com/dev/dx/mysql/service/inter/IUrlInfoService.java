package com.dev.dx.mysql.service.inter;


import com.dev.dx.mysql.domain.UrlInfo;
import com.dev.dx.mysql.utils.JSONReturn;

public interface IUrlInfoService {
    JSONReturn insertUrlInfo(UrlInfo urlInfo);
}
