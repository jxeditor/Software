package com.dev.dx.es.dao;


import com.dev.dx.es.bean.NewsInfoIndex;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface NewsInfoIndexRepository extends ElasticsearchRepository<NewsInfoIndex, String> {
}
