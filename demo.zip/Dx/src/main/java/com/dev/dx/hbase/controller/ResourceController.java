package com.dev.dx.hbase.controller;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

@RestController
@RequestMapping("/hbase")
public class ResourceController extends BaseController {
    @RequestMapping("/addResource")
    public String addResource(HttpServletRequest request) {
        JSONObject data = new JSONObject();
        ArrayList columns = new ArrayList<String>();
        ArrayList values = new ArrayList<String>();

        String rk = "";
        Map<String, String[]> parameterMap = request.getParameterMap();
        for (String key : parameterMap.keySet()) {
            if (key.equals("rk")) {
                rk = parameterMap.get(key)[0];
            } else {
                columns.add(key);
                values.add(parameterMap.get(key)[0]);
            }
        }

        try {
            hBaseUtils.getInstance().insertRecords("resource", rk, "info", (String[]) columns.toArray(new String[columns.size()]), (String[]) values.toArray(new String[values.size()]));
            data.put("status", "成功");
            data.put("rk", rk);
        } catch (IOException e) {
            e.printStackTrace();
            data.put("status", "失败");
            data.put("rk", rk);
            data.put("errorInfo", e.toString());
        }

        return data.toString();
    }

    @RequestMapping("/getResourceById")
    public String getResourceById(@RequestParam(name = "id") String id) {
        String resource = "";
        try {
            resource = hBaseUtils.getInstance().selectRow("resource", id);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return resource;
    }
}
