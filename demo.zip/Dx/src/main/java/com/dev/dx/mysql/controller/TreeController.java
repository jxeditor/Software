package com.dev.dx.mysql.controller;

import com.dev.dx.mysql.datasource.DBContextHolder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/mysql")
public class TreeController extends BaseController {

    @RequestMapping("/getArea")
    public List getArea() {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT a.area_code id, a.area_name `name`, a.parent_code pid, a.parent_codes pcodes FROM area a";
        List<Map<String, Object>> list = jdbcTemplate.query(sql, new RowMapper<Map<String, Object>>() {
            @Override
            public Map<String, Object> mapRow(ResultSet resultSet, int i) throws SQLException {
                Map<String, Object> map = new HashMap<>();
                map.put("id", resultSet.getString("id"));
                map.put("name", resultSet.getString("name"));
                map.put("pid", resultSet.getString("pid"));
                map.put("pcodes", resultSet.getString("pcodes"));
                return map;
            }
        });
        return list;
    }

    @RequestMapping("/getNewsType")
    public List getNewsType() {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT n.news_code id, n.news_name `name`, n.parent_code pid, n.parent_codes pcodes FROM news_type n";
        List<Map<String, Object>> list = jdbcTemplate.query(sql, new RowMapper<Map<String, Object>>() {
            @Override
            public Map<String, Object> mapRow(ResultSet resultSet, int i) throws SQLException {
                Map<String, Object> map = new HashMap<>();
                map.put("id", resultSet.getString("id"));
                map.put("name", resultSet.getString("name"));
                map.put("pid", resultSet.getString("pid"));
                map.put("pcodes", resultSet.getString("pcodes"));
                return map;
            }
        });
        return list;
    }

    @RequestMapping("/getResourceType")
    public List getResourceType() {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT r.resource_code id, r.resource_name `name`, r.parent_code pid, r.parent_codes pcodes FROM resource_type r";
        List<Map<String, Object>> list = jdbcTemplate.query(sql, new RowMapper<Map<String, Object>>() {
            @Override
            public Map<String, Object> mapRow(ResultSet resultSet, int i) throws SQLException {
                Map<String, Object> map = new HashMap<>();
                map.put("id", resultSet.getString("id"));
                map.put("name", resultSet.getString("name"));
                map.put("pid", resultSet.getString("pid"));
                map.put("pcodes", resultSet.getString("pcodes"));
                return map;
            }
        });
        return list;
    }

    @RequestMapping("/getResourceNodeByName")
    public String getResourceNodeByName(@RequestParam(name = "ext_name") String ext_name) {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT CONCAT(parent_codes,resource_code) node FROM resource_type WHERE resource_name=?;";
        String result = "-1";
        try {
            result = jdbcTemplate.queryForObject(sql, new Object[]{ext_name}, String.class);
        } catch (EmptyResultDataAccessException e) {
            return result;
        }
        return result;
    }


    @RequestMapping("/getResourceNameByNode")
    public String getResourceNameByNode(@RequestParam(name = "node_name") String node_name) {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT resource_name FROM resource_type WHERE CONCAT(parent_codes,resource_code) = ?;";
        String result = "-1";
        try {
            result = jdbcTemplate.queryForObject(sql, new Object[]{node_name}, String.class);
        } catch (EmptyResultDataAccessException e) {
            return result;
        }
        return result;
    }

    @RequestMapping("/getNewsTypeNameByNode")
    public String getNewsTypeNameByNode(@RequestParam(name = "news_type") String news_type) {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT news_name FROM news_type WHERE CONCAT(parent_codes,news_code) = ?;";
        String result = "-1";
        try {
            result = jdbcTemplate.queryForObject(sql, new Object[]{news_type}, String.class);
        } catch (EmptyResultDataAccessException e) {
            return result;
        }
        return result;
    }

    @RequestMapping("/getAreaNameByNode")
    public String getAreaNameByNode(@RequestParam(name = "news_region") String news_region) {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT area_name FROM `area` WHERE CONCAT(parent_codes,area_code) = ?;";
        String result = "-1";
        try {
            result = jdbcTemplate.queryForObject(sql, new Object[]{news_region}, String.class);
        } catch (EmptyResultDataAccessException e) {
            return result;
        }
        return result;
    }


    @RequestMapping("/selectTypeData")
    public String selectTypeData() {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT CONCAT(parent_codes,news_code) id, news_name `name` FROM news_type;";
        List<JSONObject> list = jdbcTemplate.query(sql, new RowMapper<JSONObject>() {
            @Override
            public JSONObject mapRow(ResultSet resultSet, int i) throws SQLException {
                JSONObject json = new JSONObject();
                json.put("id", resultSet.getString("id"));
                json.put("name", resultSet.getString("name"));
                return json;
            }
        });
        JSONArray array = new JSONArray();
        for (JSONObject json : list) {
            array.put(json);
        }
        return array.toString();
    }

    @RequestMapping("/selectRegionData")
    public String selectRegionData() {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT CONCAT(parent_codes,area_code) id, area_name `name` FROM `area`;";
        List<JSONObject> list = jdbcTemplate.query(sql, new RowMapper<JSONObject>() {
            @Override
            public JSONObject mapRow(ResultSet resultSet, int i) throws SQLException {
                JSONObject json = new JSONObject();
                json.put("id", resultSet.getString("id"));
                json.put("name", resultSet.getString("name"));
                return json;
            }
        });
        JSONArray array = new JSONArray();
        for (JSONObject json : list) {
            array.put(json);
        }
        return array.toString();
    }

    @RequestMapping("/selectUrlData")
    public String selectUrlData() {
        DBContextHolder.setDbType("secondary");
        String sql = "SELECT id, file_name `name` FROM url_sample;";
        List<JSONObject> list = jdbcTemplate.query(sql, new RowMapper<JSONObject>() {
            @Override
            public JSONObject mapRow(ResultSet resultSet, int i) throws SQLException {
                JSONObject json = new JSONObject();
                json.put("id", resultSet.getString("id"));
                json.put("name", resultSet.getString("name"));
                return json;
            }
        });
        JSONArray array = new JSONArray();
        for (JSONObject json : list) {
            array.put(json);
        }
        return array.toString();
    }
}
