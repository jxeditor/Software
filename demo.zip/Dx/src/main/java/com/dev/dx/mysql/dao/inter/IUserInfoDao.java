package com.dev.dx.mysql.dao.inter;


import com.dev.dx.mysql.domain.UserInfo;

import java.util.List;

public interface IUserInfoDao {
    List<UserInfo> getUserInfoBatch(int id);
    List<UserInfo> getUserInfoBatch(List<Integer> idList);
}
