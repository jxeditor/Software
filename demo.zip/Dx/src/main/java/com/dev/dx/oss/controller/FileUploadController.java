package com.dev.dx.oss.controller;

import com.dev.dx.oss.utils.FastDFSClientUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/oss")
public class FileUploadController {

    @RequestMapping("/fileUpload")
    public String fileUpload(HttpServletRequest request) throws Exception {
        MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
        List<MultipartFile> files = multipartHttpServletRequest.getFiles("files");
        String extName;

        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < files.size(); i++) {
            String filename = files.get(i).getOriginalFilename();
            if (StringUtils.isBlank(filename) || !filename.contains(".")) {
                extName = "";
            } else {
                extName = filename.substring(filename.lastIndexOf(".") + 1);
            }
            String fileid = FastDFSClientUtils.upload(files.get(i).getBytes(), extName);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id", fileid);
            jsonObject.put("file_name", filename);
            jsonObject.put("size", "" + files.get(i).getSize());
            jsonObject.put("ext_name", extName);
            jsonArray.put(jsonObject);
        }
        return jsonArray.toString();
    }


    // 将param转换成map格式
    public HashMap<String, String> getRequestParam(HttpServletRequest request) {
        Enumeration eObj = request.getParameterNames();
        HashMap<String, String> returnMap = null;
        if (eObj != null) {
            returnMap = new HashMap<>();
            while (eObj.hasMoreElements()) {
                Object obj = eObj.nextElement();
                if (obj == null || obj.toString().trim().length() < 1 || obj.toString().trim().equals("m") || obj.toString().equals(request.getQueryString()))
                    continue;
                Object val = request.getParameter(obj.toString());
                returnMap.put(obj.toString(), val.toString());
            }
        }
        return returnMap;
    }
}
