package com.dev.dx.mysql.service.inter.impl;


import com.dev.dx.mysql.datasource.DBContextHolder;
import com.dev.dx.mysql.domain.UserInfo;
import com.dev.dx.mysql.service.inter.IUserInfoService;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserInfoService extends BaseService implements IUserInfoService {
    @Override
    public JSONObject getUserInfoBatch(int id) {
        DBContextHolder.setDbType("primary");
        List<UserInfo> userInfoList = daoFacade.getUserInfoDao().getUserInfoBatch(id);
        return toJSONObject(userInfoList);
    }

    @Override
    public JSONObject getUserInfoBatch(List<Integer> idList) {
        DBContextHolder.setDbType("primary");
        List<UserInfo> userInfoList = daoFacade.getUserInfoDao().getUserInfoBatch(idList);
        return toJSONObject(userInfoList);
    }

    public JSONObject toJSONObject(List<UserInfo> userInfoList) {
        JSONObject data = new JSONObject();
        JSONArray infoArray = new JSONArray();
        try {
            if (userInfoList != null) {
                for (UserInfo userInfo : userInfoList) {
                    JSONObject obj = new JSONObject();
                    obj.put("id", userInfo.getId());
                    obj.put("name", userInfo.getName());
                    obj.put("age", userInfo.getAge());
                    infoArray.put(obj);
                }
            }
            data.put("infoArray", infoArray);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

}
