package com.dev.dx.mysql.controller;


import com.dev.dx.mysql.utils.ErrorCode;
import com.dev.dx.mysql.utils.JSONReturn;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mysql")
public class ResTypeIdController extends BaseController {
    @RequestMapping("/restype")
    public String getUserInfoBatch(@RequestParam(name = "ext_name", defaultValue = "-1") int id) throws Exception {
        // 进行错误处理
        if (id == -1) {
            return new JSONReturn(ErrorCode.PARAMS_ERROR).toString();
        } else {

            jdbcTemplate.queryForObject("", new Object[]{""}, String.class);
            JSONObject data = serviceFacade.getUserInfoService().getUserInfoBatch(id);
            return new JSONReturn(data).toString();
        }
    }
}
