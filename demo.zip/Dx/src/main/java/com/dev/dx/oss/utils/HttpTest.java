package com.dev.dx.oss.utils;

import java.util.HashMap;
import java.util.Map;

public class HttpTest {
    public static void main(String[] args) {
        Map params = new HashMap();
//        params.put("id","group1/M00/00/00/wKiOgFx3gN-AD1NwAAAywenroyw577.txt");
//        params.put("file_name","test.txt");
//        params.put("size","12993");
//        params.put("ext_name","txt");

        params.put("fileName","xxxxx");
//        String s = HttpUtils.sendPost("http://192.168.3.128:1113/fileUpload",params);

//        System.out.println(s);
    }
}
