package com.dev.dx.es.config;//package com.dev.servicees.config;
//
//import org.elasticsearch.client.Client;
//import org.elasticsearch.common.settings.Settings;
//import org.elasticsearch.common.transport.TransportAddress;
//import org.elasticsearch.transport.client.PreBuiltTransportClient;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Controller;
//
//import java.net.InetAddress;
//import java.net.UnknownHostException;
//
//@Component
//@Configuration
//@ConfigurationProperties(prefix = "es")
//public class EsConfig {
//    private String hosts;
//    private Integer port;
//    private String clusterName;
//
//    public String getHosts() {
//        return hosts;
//    }
//
//    public Integer getPort() {
//        return port;
//    }
//
//    public void setPort(Integer port) {
//        this.port = port;
//    }
//
//    public void setHosts(String hosts) {
//        this.hosts = hosts;
//    }
//
//    public String getClusterName() {
//        return clusterName;
//    }
//
//    public void setClusterName(String clusterName) {
//        this.clusterName = clusterName;
//    }
//
//    @Bean
//    public Client getEsClient() {
//        PreBuiltTransportClient client = null;
//        synchronized (this) {
//            if (client == null) {
//                try {
//                    Settings settings = Settings.builder().put("cluster.name", clusterName).build();
//                    String[] hostArray = hosts.split(",");
//                    client = new PreBuiltTransportClient(settings);
//                    for (String host :
//                            hostArray) {
//                        client.addTransportAddress(new TransportAddress(InetAddress.getByName(host), port));
//                    }
//                } catch (UnknownHostException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//        return client;
//    }
//}
