package com.dev.dx.mysql.service.inter;

import org.json.JSONObject;

import java.util.List;

public interface IUserInfoService {
    JSONObject getUserInfoBatch(int id);
    JSONObject getUserInfoBatch(List<Integer> idList);
}
