package com.dev.dx.mysql.service.inter.impl;


import com.dev.dx.mysql.datasource.DBContextHolder;
import com.dev.dx.mysql.domain.UrlInfo;
import com.dev.dx.mysql.service.inter.IUrlInfoService;
import com.dev.dx.mysql.utils.ErrorCode;
import com.dev.dx.mysql.utils.JSONReturn;
import org.springframework.stereotype.Service;

@Service
public class UrlInfoService extends BaseService implements IUrlInfoService {
    @Override
    public JSONReturn insertUrlInfo(UrlInfo urlInfo) {
        DBContextHolder.setDbType("secondary");
        int i = daoFacade.getUrlInfoDao().insertUrlInfo(urlInfo);

        if (i < 1) {
            return new JSONReturn(ErrorCode.INSERT_ERROR);
        } else {
            return new JSONReturn("success", "插入成功", i);
        }
    }
}
