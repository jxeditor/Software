package com.dev.dx.mysql.controller;


import com.dev.dx.mysql.domain.NewsInfo;
import com.dev.dx.mysql.utils.ErrorCode;
import com.dev.dx.mysql.utils.JSONReturn;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mysql")
public class NewsController extends BaseController {
    @RequestMapping("/insertNewsInfo")
    public String insertNewsInfo(@RequestParam(name = "id", defaultValue = "-1") String id
            , @RequestParam(name = "news_title") String news_title,
                                 @RequestParam(name = "news_type") String news_type,
                                 @RequestParam(name = "news_author") String news_author,
                                 @RequestParam(name = "news_date") String news_date,
                                 @RequestParam(name = "news_region") String news_region
    ) {
        if (id.equals("-1")) {
            return new JSONReturn(ErrorCode.PARAMS_ERROR).toString();
        } else {
            NewsInfo newsInfo = new NewsInfo();
            newsInfo.setId(id);
            newsInfo.setNews_author(news_author);
            newsInfo.setNews_type(news_type);
            newsInfo.setNews_region(news_region);
            newsInfo.setNews_title(news_title);
            newsInfo.setNews_date(news_date);
            return serviceFacade.getNewsInfoService().insertNewsInfo(newsInfo).toString();
        }
    }
}
