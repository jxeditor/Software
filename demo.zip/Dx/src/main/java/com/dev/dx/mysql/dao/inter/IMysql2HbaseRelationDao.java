package com.dev.dx.mysql.dao.inter;


import com.dev.dx.mysql.domain.Mysql2HbaseRelation;

public interface IMysql2HbaseRelationDao {
    int insertM2HRelation(Mysql2HbaseRelation mysql2HbaseRelation);

    String getM2HRelationById(String id);
}
