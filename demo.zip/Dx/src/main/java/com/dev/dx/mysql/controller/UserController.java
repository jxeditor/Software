package com.dev.dx.mysql.controller;

import com.dev.dx.mysql.utils.ErrorCode;
import com.dev.dx.mysql.utils.JSONReturn;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/mysql")
public class UserController extends BaseController {

    @RequestMapping("/getUserInfoByParam")
    public String getUserInfoBatch(@RequestParam(name = "id", required = true, defaultValue = "-1") int id) throws Exception {
        // 进行错误处理
        if (id == -1) {
            return new JSONReturn(ErrorCode.PARAMS_ERROR).toString();
        } else {
            JSONObject data = serviceFacade.getUserInfoService().getUserInfoBatch(id);
            return new JSONReturn(data).toString();
        }
    }

    // 以请求的方式,参数可以是数组
    @RequestMapping(value = "/getUserInfoByHttp")
    public String getUserInfoBatch(HttpServletRequest request) throws Exception {
        HashMap<String, String> params = getRequestParam(request);
        if (!params.containsKey("id")) {
            return new JSONReturn(ErrorCode.PARAMS_ERROR).toString();
        }
        JSONArray idArray = new JSONArray(params.get("id"));
        params.remove("id");
        List<Integer> idList = new ArrayList<>();
        for (int i = 0; i < idArray.length(); i++) {
            idList.add(idArray.getInt(i));
        }
        JSONObject data = serviceFacade.getUserInfoService().getUserInfoBatch(idList);
        return new JSONReturn(data).toString();
    }
}
