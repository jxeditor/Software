package com.dev.dx.mysql.service.inter;


import com.dev.dx.mysql.domain.NewsInfo;
import com.dev.dx.mysql.utils.JSONReturn;

public interface INewsInfoService {
    JSONReturn insertNewsInfo(NewsInfo newsInfo);
}
