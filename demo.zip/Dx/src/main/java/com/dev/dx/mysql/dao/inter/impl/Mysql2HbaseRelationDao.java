package com.dev.dx.mysql.dao.inter.impl;

import com.dev.dx.mysql.dao.inter.IMysql2HbaseRelationDao;
import com.dev.dx.mysql.domain.Mysql2HbaseRelation;
import com.google.gson.Gson;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class Mysql2HbaseRelationDao extends BaseDao implements IMysql2HbaseRelationDao {
    @Override
    public int insertM2HRelation(Mysql2HbaseRelation mysql2HbaseRelation) {
        String sql = "insert into m2h_relation(`m_id`, `h_rk`) values(?,?)";
        return jdbcTemplate.update(sql, new Object[]{mysql2HbaseRelation.getMysqlId(), mysql2HbaseRelation.getHbaseRowkey()});
    }

    @Override
    public String getM2HRelationById(String id) {
        String sql = "select m_id,h_rk from m2h_relation where m_id = ?";
        List<Mysql2HbaseRelation> result = jdbcTemplate.query(sql, new Object[]{id}, new RowMapper<Mysql2HbaseRelation>() {
            @Override
            public Mysql2HbaseRelation mapRow(ResultSet resultSet, int i) throws SQLException {
                Mysql2HbaseRelation mysql2HbaseRelation = new Mysql2HbaseRelation();
                mysql2HbaseRelation.setMysqlId(resultSet.getString("m_id"));
                mysql2HbaseRelation.setHbaseRowkey(resultSet.getString("h_rk"));
                return mysql2HbaseRelation;
            }
        });

        return new Gson().toJson(result);
    }
}
