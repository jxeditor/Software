package com.dev.dx.es.controller;

import com.google.gson.Gson;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.text.Text;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping(value = "/es")
public class NewsInfoIndexController extends BaseController {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @RequestMapping("/addNewsInfoIndex")
    public String addNewsInfoIndex(HttpServletRequest request) {

        Map<String, String[]> parameterMap = request.getParameterMap();
        JSONObject json = new JSONObject();
        for (String key :
                parameterMap.keySet()) {
            if (key.equals("f_type")) {
                System.out.println(parameterMap.get(key)[0]);
                json.put(key, new JSONArray(parameterMap.get(key)[0].split("|")));
            } else {
                json.put(key, parameterMap.get(key)[0]);
            }
        }

        IndexResponse response = null;

        Client client = elasticsearchTemplate.getClient();
        IndexRequestBuilder indexRequestBuilder = client.prepareIndex("news", "resource", json.get("id").toString());
        response = indexRequestBuilder.setSource(json.toString(), XContentType.JSON).get();
        return response.getId();
    }

    @RequestMapping("/findNewsInfoIndexByKeyWord")
    public String findNewsInfoIndexByKeyWord(@RequestParam(name = "keyWords", required = false) String keyWords,
                                             @RequestParam(name = "keyWords2", required = false) String keyWords2,
                                             @RequestParam(name = "news_region", defaultValue = "*") String news_region,
                                             @RequestParam(name = "news_type", defaultValue = "*") String news_type,
                                             @RequestParam(name = "f_type", defaultValue = "*") String f_type,
                                             @RequestParam(name = "pageNum", defaultValue = "1") Integer pageNum,
                                             @RequestParam(name = "pageSize", defaultValue = "3") Integer pageSize) {
        // 高亮设置
        HighlightBuilder highlightBuilder = new HighlightBuilder();
        highlightBuilder.preTags("<font color='red' >");
        highlightBuilder.postTags("</font>");

        // 高亮字段
        String[] searchFields = {"news_author", "news_title", "resource"};
        for (String field : searchFields) {
            highlightBuilder.field(field);
        }

        // 查询索引及分页
        String index = "news";
        String type = "resource";
        int start = (pageNum - 1) * pageSize;
        int row = pageSize;

        Client client = elasticsearchTemplate.getClient();
        SearchRequestBuilder builder = client.prepareSearch(index);
        builder.highlighter(highlightBuilder);
        builder.setTypes(type);
        builder.setFrom(start);
        builder.setSize(row);
        builder.setSearchType(SearchType.DFS_QUERY_THEN_FETCH);

        if (StringUtils.isNotBlank(keyWords)) {
            BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
                    .must(QueryBuilders.wildcardQuery("news_region", news_region))
                    .must(QueryBuilders.wildcardQuery("news_type", news_type))
                    .must(QueryBuilders.wildcardQuery("f_type", f_type))
                    .must(QueryBuilders.multiMatchQuery(keyWords, searchFields));
            // 二次查询
            if (StringUtils.isNotBlank(keyWords2)) {
                boolQueryBuilder.must(QueryBuilders.multiMatchQuery(keyWords2, searchFields));
            }

            builder.setQuery(boolQueryBuilder);
        }
        builder.setExplain(true);

        SearchResponse searchResponse = builder.get();
        SearchHits hits = searchResponse.getHits();
        long total = hits.getTotalHits();

        Map<String, Object> map = new HashMap<>();
        SearchHit[] hits2 = hits.getHits();
        map.put("count", total);

        List<Map<String, Object>> list = new ArrayList<>();
        for (SearchHit searchHit : hits2) {
            Map<String, HighlightField> highlightFields = searchHit.getHighlightFields();
            Map<String, Object> source = searchHit.getSourceAsMap();

            // 高亮字段替换
            for (String field : searchFields) {
                HighlightField highlightField = highlightFields.get(field);
                if (highlightField != null) {
                    Text[] fragments = highlightField.fragments();
                    String name = "";
                    for (Text text : fragments) {
                        name += text;
                    }
                    source.put(field, name);
                }
            }
            list.add(source);
        }
        map.put("dataList", list);
        return new Gson().toJson(map);
    }
}
