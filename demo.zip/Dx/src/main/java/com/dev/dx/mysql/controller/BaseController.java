package com.dev.dx.mysql.controller;

import com.dev.dx.global.Controller;
import com.dev.dx.mysql.service.ServiceFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.HashMap;

public class BaseController extends Controller {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    ServiceFacade serviceFacade;
}
