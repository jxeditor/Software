package com.dev.dx.mysql.service.inter.impl;


import com.dev.dx.mysql.datasource.DBContextHolder;
import com.dev.dx.mysql.domain.Mysql2HbaseRelation;
import com.dev.dx.mysql.service.inter.IMysql2HbaseRelationService;
import com.dev.dx.mysql.utils.ErrorCode;
import com.dev.dx.mysql.utils.JSONReturn;
import org.springframework.stereotype.Service;

@Service
public class Mysql2HbaseRelationService extends BaseService implements IMysql2HbaseRelationService {
    @Override
    public JSONReturn insertM2HRelation(Mysql2HbaseRelation mysql2HbaseRelation) {
        DBContextHolder.setDbType("secondary");
        int i = daoFacade.getMysql2HbaseRelationDao().insertM2HRelation(mysql2HbaseRelation);

        if (i < 1) {
            return new JSONReturn(ErrorCode.INSERT_ERROR);
        } else {
            return new JSONReturn("success", "插入成功", i);
        }
    }

    @Override
    public String getM2HRelationById(String id) {
        DBContextHolder.setDbType("secondary");
        String result = daoFacade.getMysql2HbaseRelationDao().getM2HRelationById(id);
        return result;
    }
}
