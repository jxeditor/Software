package com.dev.dx.mysql.dao.inter;


import com.dev.dx.mysql.domain.UrlInfo;

public interface IUrlInfoDao {
    int insertUrlInfo(UrlInfo urlInfo);
}
