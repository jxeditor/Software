package com.dev.dx.mysql.controller;

import com.dev.dx.mysql.domain.UrlInfo;
import com.dev.dx.mysql.utils.ErrorCode;
import com.dev.dx.mysql.utils.JSONReturn;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mysql")
public class UrlController extends BaseController {
    @RequestMapping("/insertUrlInfo")
    public String insertUrlInfo(@RequestParam(name = "id", required = true, defaultValue = "-1") String id
            , @RequestParam(name = "file_name", required = false) String file_name,
                       @RequestParam(name = "size", required = false) String size,
                       @RequestParam(name = "ext_name", required = false) String ext_name
    ) {
        if (id.equals("-1")) {
            return new JSONReturn(ErrorCode.PARAMS_ERROR).toString();
        } else {
            UrlInfo urlInfo = new UrlInfo();
            urlInfo.setId(id);
            urlInfo.setFile_name(file_name);
            urlInfo.setSize(Long.parseLong(size));
            urlInfo.setExt_name(ext_name);
            return serviceFacade.getUrlInfoService().insertUrlInfo(urlInfo).toString();
        }
    }
}
