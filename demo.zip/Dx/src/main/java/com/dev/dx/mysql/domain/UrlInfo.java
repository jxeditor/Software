package com.dev.dx.mysql.domain;

public class UrlInfo {
    private String id;
    private String file_name;
    private long size;
    private String ext_name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public String getExt_name() {
        return ext_name;
    }

    public void setExt_name(String ext_name) {
        this.ext_name = ext_name;
    }
}
