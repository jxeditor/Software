package com.dev.dx.mysql.service.inter;


import com.dev.dx.mysql.domain.Mysql2HbaseRelation;
import com.dev.dx.mysql.utils.JSONReturn;

public interface IMysql2HbaseRelationService {
    JSONReturn insertM2HRelation(Mysql2HbaseRelation mysql2HbaseRelation);

    String getM2HRelationById(String id);
}
