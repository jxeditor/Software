package com.dev.dx.mysql.service;

import com.dev.dx.mysql.service.inter.IMysql2HbaseRelationService;
import com.dev.dx.mysql.service.inter.INewsInfoService;
import com.dev.dx.mysql.service.inter.IUrlInfoService;
import com.dev.dx.mysql.service.inter.IUserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 外观模式
 * Service
 */
@Service
public class ServiceFacade {
    @Autowired
    IUserInfoService userInfoService;

    public IUserInfoService getUserInfoService() {
        return userInfoService;
    }

    @Autowired
    IUrlInfoService urlInfoService;

    public IUrlInfoService getUrlInfoService() {
        return urlInfoService;
    }

    @Autowired
    INewsInfoService newsInfoService;

    public INewsInfoService getNewsInfoService() {
        return newsInfoService;
    }

    @Autowired
    IMysql2HbaseRelationService mysql2HbaseRelationService;

    public IMysql2HbaseRelationService getMysql2HbaseRelationService() {
        return mysql2HbaseRelationService;
    }
}