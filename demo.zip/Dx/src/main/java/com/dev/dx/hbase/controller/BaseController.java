package com.dev.dx.hbase.controller;


import com.dev.dx.global.Controller;
import com.dev.dx.hbase.utils.HBaseUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.HashMap;

public class BaseController extends Controller {

    @Autowired
    HBaseUtils hBaseUtils;

//    @Autowired
//    DiscoveryClient discoveryClient;
}
