package com.dev.dx.mysql.dao.inter;


import com.dev.dx.mysql.domain.NewsInfo;

public interface INewsInfoDao {
    int insertNewsInfo(NewsInfo newsInfo);
}
