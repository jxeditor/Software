package com.dev.dx.mysql.service.inter.impl;


import com.dev.dx.mysql.datasource.DBContextHolder;
import com.dev.dx.mysql.domain.NewsInfo;
import com.dev.dx.mysql.service.inter.INewsInfoService;
import com.dev.dx.mysql.utils.ErrorCode;
import com.dev.dx.mysql.utils.JSONReturn;
import org.springframework.stereotype.Service;

@Service
public class NewsInfoService extends BaseService implements INewsInfoService {
    @Override
    public JSONReturn insertNewsInfo(NewsInfo newsInfo) {
        DBContextHolder.setDbType("secondary");
        int i = daoFacade.getNewsInfoDao().insertNewsInfo(newsInfo);

        if (i < 1) {
            return new JSONReturn(ErrorCode.INSERT_ERROR);
        } else {
            return new JSONReturn("success", "插入成功", i);
        }
    }
}
