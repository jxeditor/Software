package com.dev.dx.mysql.domain;

public class Mysql2HbaseRelation {
    private String mysqlId;
    private String HbaseRowkey;

    public String getMysqlId() {
        return mysqlId;
    }

    public void setMysqlId(String mysqlId) {
        this.mysqlId = mysqlId;
    }

    public String getHbaseRowkey() {
        return HbaseRowkey;
    }

    public void setHbaseRowkey(String hbaseRowkey) {
        HbaseRowkey = hbaseRowkey;
    }
}
