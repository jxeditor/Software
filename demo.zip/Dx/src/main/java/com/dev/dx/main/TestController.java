package com.dev.dx.main;

import com.google.gson.Gson;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class TestController {

    @Value("${dataUrl}")
    String dataUrl;

    @RequestMapping("/demo")
    public String demo() {
        return "demo";
    }

    @RequestMapping("/file")
    public String file() {
        return "file";
    }

    @RequestMapping("/index")
    public String index() {
        return "index";
    }

    @RequestMapping("/re")
    public String test() {
        return "test";
    }

    @RequestMapping("/test")
    @ResponseBody
    public String test(HttpServletRequest request) throws IOException {
        MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
        Map<String, String[]> parameterMap = multipartHttpServletRequest.getParameterMap();
        for (String key : parameterMap.keySet()) {
            for (String value : parameterMap.get(key)) {
                System.out.println(key + "---" + value);
            }
        }
        List<MultipartFile> multipartFiles = multipartHttpServletRequest.getFiles("fileName");
        if (multipartFiles.get(0).getOriginalFilename().equals("")) {
            // 没有文件上传
            System.out.println("没有上传");
        } else {
            // 有文件上传
            for (int i = 0; i < multipartFiles.size(); i++) {
                System.out.println(multipartFiles.get(i).getOriginalFilename());
            }
        }
        return "";
    }


    @RequestMapping("/uploadData")
    @ResponseBody
    public String uploadData(HttpServletRequest request) throws IOException {
        JSONObject data = new JSONObject();
        Map m2hRelationMap = new HashMap(); // 存储新闻Id与Hbase中资源rowkey的对应关系
        Map urlInfoMap = new HashMap(); // 存储资源url与原始文件名的对应关系
        Map newsInfoMap = new HashMap(); // 存储新闻基本信息
        Map hbaseInfoMap = new HashMap(); // 存储在hbase上的资源<正文与文件>
        Map esIndexInfoMap = new HashMap(); // 存储在ES上的索引信息


        MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;

        String news_id = UUID.randomUUID().toString();
        String news_context = "";


        Map<String, String[]> parameterMap = multipartHttpServletRequest.getParameterMap();

        newsInfoMap.put("id", news_id);
        for (String key : parameterMap.keySet()) {
            if (key.equals("news_context")) {
                news_context = parameterMap.get("news_context")[0];
            } else {
                for (String value : parameterMap.get(key)) {
                    newsInfoMap.put(key, value);
                }
            }
        }

        // 填充ES上的Index数据
        esIndexInfoMap.putAll(newsInfoMap);
        esIndexInfoMap.put("resource", news_context);

        // 前端传递过来的news_type与news_region为id形式,需要进行转换
        newsInfoMap.put("news_type", HttpUtils.sendPost(dataUrl + "mysql/getNewsTypeNameByNode", esIndexInfoMap));
        newsInfoMap.put("news_region", HttpUtils.sendPost(dataUrl + "mysql/getAreaNameByNode", esIndexInfoMap));

        // 调用MySQL服务接口存储新闻基本信息
        HttpUtils.sendPost(dataUrl +"mysql/insertNewsInfo", newsInfoMap);

        // 存储新闻正文信息到Hbase并存储对应关系
        String contextRowKey = UUID.randomUUID().toString();
        hbaseInfoMap.putAll(newsInfoMap);
        hbaseInfoMap.put("resource", news_context);
        hbaseInfoMap.put("resource_type", "text");
        hbaseInfoMap.put("rk", contextRowKey);

        System.out.println("hbaseInfoMap");
        for (Object key : hbaseInfoMap.keySet()) {
            System.out.println(key + "---" + hbaseInfoMap.get(key));
        }

        HttpUtils.sendPost(dataUrl + "hbase/addResource", hbaseInfoMap);

        m2hRelationMap.put("m_id", news_id);
        m2hRelationMap.put("h_rk", contextRowKey);
        HttpUtils.sendPost(dataUrl + "mysql/insertM2HRelation", m2hRelationMap);


        ArrayList list = new ArrayList();
        // 文件存储服务调用并存储文件名对应关系到MySQL,并完善ES的index数据
        List<MultipartFile> multipartFiles = multipartHttpServletRequest.getFiles("fileName");
        if (multipartFiles.get(0).getOriginalFilename().equals("")) {
            // 没有文件上传
            data.put("fileUpload", 0);
        } else {
            // 有文件上传
            Map<String, String> result = HttpUtils.sendPost(dataUrl + "oss/fileUpload", multipartFiles, "files", null, -1);
            JSONArray jsonArray = new JSONArray(result.get("data"));
            for (int i = 0; i < jsonArray.length(); i++) {
                String rowKey = UUID.randomUUID().toString();
                urlInfoMap.clear();
                urlInfoMap.put("id", jsonArray.getJSONObject(i).get("id"));
                urlInfoMap.put("file_name", jsonArray.getJSONObject(i).get("file_name"));
                urlInfoMap.put("size", "" + jsonArray.getJSONObject(i).get("size"));
                urlInfoMap.put("ext_name", jsonArray.getJSONObject(i).get("ext_name"));
//             存储url路径与原始文件名对应关系
                HttpUtils.sendPost(dataUrl + "mysql/insertUrlInfo", urlInfoMap);

                // 将url信息存储到HBase中<rowkey----urlInfo>
                hbaseInfoMap.putAll(newsInfoMap);
                hbaseInfoMap.put("resource", jsonArray.getJSONObject(i).get("id"));
                hbaseInfoMap.put("resource_type", jsonArray.getJSONObject(i).get("ext_name"));
                hbaseInfoMap.put("rk", rowKey);
                HttpUtils.sendPost(dataUrl + "hbase/addResource", hbaseInfoMap);

                // 存储MySQL与HBase对应关系数据<news_id---rowkey>
                m2hRelationMap.clear();
                m2hRelationMap.put("m_id", news_id);
                m2hRelationMap.put("h_rk", rowKey);
                HttpUtils.sendPost(dataUrl + "mysql/insertM2HRelation", m2hRelationMap);

                // TODO 去数据库查找ext_name对应的id,没有找到就存入-1,进行去重
                String f_type_id = HttpUtils.sendPost(dataUrl + "mysql/getResourceNodeByName", urlInfoMap);
                list.add(f_type_id);
            }
            data.put("fileUpload", jsonArray.length());
        }
        // 类型默认为0
        list.add("0");
        list = (ArrayList) list.stream().distinct().collect(Collectors.toList());
        esIndexInfoMap.put("f_type", String.join("|", list));
        // TODO 如果存在上传文件的话应该有对应的资源文件类型id
        HttpUtils.sendPost(dataUrl + "es/addNewsInfoIndex", esIndexInfoMap);


        return data.toString();
    }


    @RequestMapping("/search.do")
    public String serachArticle(Model model,
                                @RequestParam(value = "keyWords", required = false, defaultValue = "") String keyWords,
                                @RequestParam(value = "keyWords2", required = false, defaultValue = "") String keyWords2,
                                @RequestParam(name = "news_region", defaultValue = "") String news_region,
                                @RequestParam(name = "news_type", defaultValue = "") String news_type,
                                @RequestParam(name = "f_type", defaultValue = "") String f_type,
                                @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
                                @RequestParam(value = "pageSize", defaultValue = "3") Integer pageSize) {

        Map<String, String> params = new HashMap<>();
        params.put("keyWords", keyWords);
        params.put("keyWords2", keyWords2);
        params.put("news_region", news_region + "*");
        params.put("news_type", news_type + "*");
        params.put("f_type", f_type + "*");
        params.put("pageNum", pageNum.toString());
        params.put("pageSize", pageSize.toString());

        int count = 0;

        String json = HttpUtils.sendPost(dataUrl + "es/findNewsInfoIndexByKeyWord", params);
        System.out.println(json);
        JSONObject jsonObject = new JSONObject(json);


        count = Integer.parseInt(jsonObject.get("count").toString());

        PageUtil<Map<String, Object>> page = new PageUtil<>(String.valueOf(pageNum), String.valueOf(pageSize), count);

        JSONArray dataList = jsonObject.getJSONArray("dataList");
        List articleList = new ArrayList<>();

        for (int i = 0; i < dataList.length(); i++) {
            NewsInfoIndex newsInfoIndex = new Gson().fromJson(dataList.getJSONObject(i).toString(), NewsInfoIndex.class);
            articleList.add(newsInfoIndex);
        }

        page.setList(articleList);
        model.addAttribute("total", count);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("page", page);
        System.out.println(keyWords);
        model.addAttribute("kw", keyWords);
        return "secondsearch";
    }

    @RequestMapping("/detailDocById/{id}.do")
    public String detailArticleById(@PathVariable(value = "id") String id, Model modelMap) throws IOException {
        // 获取RK
        String m2h = HttpUtils.sendPost(dataUrl + "mysql/getM2HRelationById?id=" + id);
        JSONArray jsonArray = new JSONArray(m2h);
        NewsDetailInfo newsDetailInfo = new NewsDetailInfo();
        ArrayList resources = new ArrayList();

        // 去HBase中取详细信息
        for (int i = 0; i < jsonArray.length(); i++) {
            String hbaseRowkey = jsonArray.getJSONObject(i).get("HbaseRowkey").toString();
            String info = HttpUtils.sendPost(dataUrl + "hbase/getResourceById?id=" + hbaseRowkey);
            JSONObject json = new JSONObject(info);
            if (i == 0) {
                newsDetailInfo.setId(json.get("id").toString());
                newsDetailInfo.setNews_author(json.get("news_author").toString());
                newsDetailInfo.setNews_date(json.get("news_date").toString());
                newsDetailInfo.setNews_region(json.get("news_region").toString());
                newsDetailInfo.setNews_title(json.get("news_title").toString());
                newsDetailInfo.setNews_type(json.get("news_type").toString());
            }
            if (json.get("resource_type").equals("text")) {
                resources.add(json.get("resource_type") + ":" + json.get("resource").toString());
            } else {
                resources.add(json.get("resource_type") + ":<a target='_blank' href='http://192.168.142.128:8077/" + json.get("resource") + "'> http://192.168.142.128:8077/" + json.get("resource") + "</a>");
            }
        }

        newsDetailInfo.setResources(resources);


        modelMap.addAttribute("newsDetailInfo", newsDetailInfo);
        return "detail";
    }

}
