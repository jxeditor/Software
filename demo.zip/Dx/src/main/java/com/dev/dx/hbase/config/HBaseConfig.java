package com.dev.dx.hbase.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * @Author: xs
 * @Date: 2019/2/23 9:35
 * @Version 1.0
 */
@Configuration
@ConfigurationProperties(prefix = HBaseConfig.CONF_PREFIX)
public class HBaseConfig {

    public static final String CONF_PREFIX = "hbase.conf";

    private Map<String, String> confMaps;

    public Map<String, String> getconfMaps() {
        return confMaps;
    }

    public void setconfMaps(Map<String, String> confMaps) {
        this.confMaps = confMaps;
    }
}