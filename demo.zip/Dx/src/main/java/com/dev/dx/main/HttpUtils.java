package com.dev.dx.main;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.*;

public class HttpUtils {
    private static Logger logger = LogManager.getLogger(HttpUtils.class);

    public static Map<String, String> sendPost(String url, List<MultipartFile> multipartFiles, String fileParName, Map<String, Object> params, int timeout) {
        Map<String, String> resultMap = new HashMap<>();

        CloseableHttpClient httpClient = HttpClients.createDefault();
        String result = "";
        try {

            HttpPost httpPost = new HttpPost(url);
            MultipartEntityBuilder builder = MultipartEntityBuilder.create()
                    .setCharset(java.nio.charset.Charset.forName("UTF-8"))
                    .setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            String fileName = null;
            MultipartFile multipartFile = null;

            for (int i = 0; i < multipartFiles.size(); i++) {
                multipartFile = multipartFiles.get(i);
                fileName = multipartFile.getOriginalFilename();

                builder.addBinaryBody(fileParName, multipartFile.getInputStream(), ContentType.MULTIPART_FORM_DATA, fileName);
            }

            ContentType contentType = ContentType.create(HTTP.PLAIN_TEXT_TYPE, HTTP.UTF_8);

            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);
            HttpResponse response = httpClient.execute(httpPost);

            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(timeout)
                    .setConnectionRequestTimeout(timeout)
                    .setSocketTimeout(timeout)
                    .build();
            httpPost.setConfig(requestConfig);

            HttpEntity responseEntity = response.getEntity();
            resultMap.put("scode", String.valueOf(response.getStatusLine().getStatusCode()));
            resultMap.put("data", "");
            if (responseEntity != null) {
                result = EntityUtils.toString(responseEntity, java.nio.charset.Charset.forName("UTF-8"));
                resultMap.put("data", result);
            }
        } catch (Exception e) {
            resultMap.put("scode", "error");
            resultMap.put("data", "HTTP请求出现异常: " + e.getMessage());
            Writer w = new StringWriter();
            e.printStackTrace(new PrintWriter(w));
            logger.error("HTTP出现异常: " + w.toString());
        } finally {
            try {
                httpClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return resultMap;
    }

    public static String sendPost(String url, Map<String, String> params) {
        String rtn = null;
        RequestConfig defaultRequestConfig = RequestConfig.custom()
                .setSocketTimeout(30000)
                .setConnectTimeout(30000)
                .setConnectionRequestTimeout(30000)
                .build();
        CloseableHttpClient client = HttpClients
                .custom()
                .setDefaultRequestConfig(defaultRequestConfig)
                .build();
        HttpPost httpPost = new HttpPost(url);
        UrlEncodedFormEntity uefEntity;
        try {
            List<NameValuePair> pairList = new ArrayList<NameValuePair>();
            if (params != null && params.size() > 0) {
                Set<String> keySet = params.keySet();
                for (String key : keySet) {
                    pairList.add(new BasicNameValuePair(key, params.get(key).toString()));
                }
            }

            uefEntity = new UrlEncodedFormEntity(pairList, "UTF-8");
            httpPost.setEntity(uefEntity);

            CloseableHttpResponse response = client.execute(httpPost);
            try {
                logger.info("HttpPost : " + url);
                logger.info("Post Status is " + response.getStatusLine());
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    rtn = EntityUtils.toString(entity, "UTF-8");
                    logger.info("Post Response is : " + rtn);
                }
            } finally {
                response.close();
            }
        } catch (ClientProtocolException e) {
            logger.catching(e);
        } catch (UnsupportedEncodingException e1) {
            logger.catching(e1);
        } catch (IOException e) {
            logger.catching(e);
        } finally {
            // 关闭连接,释放资源
            try {
                client.close();
            } catch (IOException e) {
                logger.catching(e);
            }
            return rtn;
        }
    }

    public static String sendGet(String url, Map<String, String> params) {
        String rtn = null;
        RequestConfig defaultRequestConfig = RequestConfig.custom()
                .setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .setConnectionRequestTimeout(5000)
                .build();
        CloseableHttpClient client = HttpClients
                .custom()
                .setDefaultRequestConfig(defaultRequestConfig)
                .build();
        try {
            if (params != null && params.size() > 0) {
                url += "?";
                Set<String> keySet = params.keySet();
                for (String key : keySet) {
                    url += key + "=" + params.get(key).toString() + "&";
                }
                url = url.substring(0, url.length() - 1);
            }

            // 创建httpget.
            HttpGet httpget = new HttpGet(url);
            // 执行get请求.
            CloseableHttpResponse response = client.execute(httpget);
            try {
                logger.info("HttpGet : " + url);
                logger.info("Get Status is " + response.getStatusLine());
                // 获取响应实体
                HttpEntity entity = response.getEntity();
                // 打印响应状态
                if (entity != null) {
                    // 打印响应内容
                    rtn = EntityUtils.toString(entity);
                    logger.info("Get Response is : " + rtn);
                }
            } finally {
                response.close();
            }
        } catch (ClientProtocolException e) {
            logger.catching(e);
        } catch (ParseException e) {
            logger.catching(e);
        } catch (IOException e) {
            logger.catching(e);
        } finally {
            // 关闭连接,释放资源
            try {
                client.close();
            } catch (IOException e) {
                logger.catching(e);
            }
            return rtn;
        }
    }

    public static String sendGet(String url) {
        return sendGet(url, null);
    }

    public static String sendPost(String url) {

        return sendPost(url, null);
    }

    public static void main(String[] args) {
//        Map<String, String> params = new HashMap<>();
//        params.put("keyWords", "中国");
//        params.put("pageNum", "1");
//        params.put("pageSize", "3");
//        String json = HttpUtils.sendPost("http://192.168.3.128:1115/es/findNewsInfoIndexByKeyWord", params);
//
//        System.out.println(json);
        String json = "{'test':"+null+",'after':{'user_id':376,'ques_id':41234}}";
        JSONObject kafkaData = new JSONObject(json);

//        JSONObject j = new JSONObject(kafkaData.get("after"));
//        System.out.println(kafkaData.get("after"));
//        JSONObject after = kafkaData.getJSONObject("after");
//        System.out.println(after.get("user_id") + "-" + after.get("ques_id"));

        Map<String, String> params = new HashMap<>();
        params.put("keyWords", "");
        params.put("keyWords2", "");
        params.put("pageNum", "1");
        params.put("pageSize", "3");

        int count = 0;

        // String json = HttpUtils.sendPost("http://192.168.3.128:1115/es/findNewsInfoIndexByKeyWord", params);

        // System.out.println(json);


    }
}
