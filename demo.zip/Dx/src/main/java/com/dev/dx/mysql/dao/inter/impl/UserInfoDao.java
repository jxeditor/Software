package com.dev.dx.mysql.dao.inter.impl;


import com.dev.dx.mysql.dao.inter.IUserInfoDao;
import com.dev.dx.mysql.domain.UserInfo;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UserInfoDao extends BaseDao implements IUserInfoDao {

    @Override
    public List<UserInfo> getUserInfoBatch(int id) {
        String sql = "SELECT * FROM customer WHERE id=?";
        return jdbcTemplate.query(sql, new Object[]{id}, new UserInfoRowMapper());
    }

    @Override
    public List<UserInfo> getUserInfoBatch(List<Integer> idList) {
        String sql = "SELECT * FROM customer WHERE id=?";
        List<UserInfo> result = new ArrayList<>();
        for (int id : idList){
            result.addAll(jdbcTemplate.query(sql, new Object[]{id}, new UserInfoRowMapper()));
        }
        return result;
    }

    class UserInfoRowMapper implements RowMapper<UserInfo> {
        @Override
        public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
            UserInfo userInfo = new UserInfo();
            userInfo.setId(rs.getInt("id"));
            userInfo.setName(rs.getString("name"));
            userInfo.setAge(rs.getInt("age"));
            return userInfo;
        }
    }

    // es查询
//    public SearchRequest getUserDirScoreBatch(List<Long> jidList, List<Long> dirList) {
//        if (jidList == null || dirList == null || dirList.size() < 1 || jidList.size() < 1)
//            return null;
//
//        SearchRequest searchRequest = new SearchRequest();
//        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
//        searchSourceBuilder.query(QueryBuilders.matchAllQuery());
//        System.out.println(searchRequest.toString());
//        return searchRequest.source(searchSourceBuilder);
//    }
}
