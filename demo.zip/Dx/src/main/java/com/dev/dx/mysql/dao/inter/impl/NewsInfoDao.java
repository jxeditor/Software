package com.dev.dx.mysql.dao.inter.impl;


import com.dev.dx.mysql.dao.inter.INewsInfoDao;
import com.dev.dx.mysql.domain.NewsInfo;
import org.springframework.stereotype.Repository;

@Repository
public class NewsInfoDao extends BaseDao implements INewsInfoDao {

    @Override
    public int insertNewsInfo(NewsInfo newsInfo) {
        String sql = "insert into news_sample(`id`, `news_author`, `news_date`, `news_region`,`news_title`,`news_type`) values(?,?,?,?,?,?)";
        System.out.println(newsInfo);
        return jdbcTemplate.update(sql, new Object[]{newsInfo.getId(), newsInfo.getNews_author(), newsInfo.getNews_date(), newsInfo.getNews_region(), newsInfo.getNews_title(), newsInfo.getNews_type()});
    }

}
