package com.dev.dx.mysql.dao.inter.impl;

import com.dev.dx.mysql.dao.inter.IUrlInfoDao;
import com.dev.dx.mysql.domain.UrlInfo;
import org.springframework.stereotype.Repository;

@Repository
public class UrlInfoDao extends BaseDao implements IUrlInfoDao {
    @Override
    public int insertUrlInfo(UrlInfo urlInfo) {
        String sql = "insert into url_sample(`id`, `file_name`, `size`, `ext_name`) values(?,?,?,?)";
        return jdbcTemplate.update(sql, new Object[]{urlInfo.getId(),urlInfo.getFile_name(),urlInfo.getSize(),urlInfo.getExt_name()});
    }
}
