package com.dev.dx.mysql.dao;

import com.dev.dx.mysql.dao.inter.IMysql2HbaseRelationDao;
import com.dev.dx.mysql.dao.inter.INewsInfoDao;
import com.dev.dx.mysql.dao.inter.IUrlInfoDao;
import com.dev.dx.mysql.dao.inter.IUserInfoDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * 外观模式
 * Dao
 */
@Repository
public class DaoFacade {
    @Autowired
    IUserInfoDao userInfoDao;

    public IUserInfoDao getUserInfoDao() {
        return userInfoDao;
    }

    @Autowired
    IUrlInfoDao urlInfoDao;

    public IUrlInfoDao getUrlInfoDao() {
        return urlInfoDao;
    }

    @Autowired
    INewsInfoDao newsInfoDao;

    public INewsInfoDao getNewsInfoDao() {
        return newsInfoDao;
    }


    @Autowired
    IMysql2HbaseRelationDao mysql2HbaseRelationDao;

    public IMysql2HbaseRelationDao getMysql2HbaseRelationDao() {
        return mysql2HbaseRelationDao;
    }
}
