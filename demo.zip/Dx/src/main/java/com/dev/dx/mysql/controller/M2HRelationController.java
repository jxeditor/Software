package com.dev.dx.mysql.controller;

import com.dev.dx.mysql.domain.Mysql2HbaseRelation;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mysql")
public class M2HRelationController extends BaseController {
    @RequestMapping("/insertM2HRelation")
    public String insertM2HRelation(@RequestParam(name = "m_id") String m_id
            , @RequestParam(name = "h_rk") String h_rk
    ) {
        Mysql2HbaseRelation mysql2HbaseRelation = new Mysql2HbaseRelation();
        mysql2HbaseRelation.setMysqlId(m_id);
        mysql2HbaseRelation.setHbaseRowkey(h_rk);
        return serviceFacade.getMysql2HbaseRelationService().insertM2HRelation(mysql2HbaseRelation).toString();
    }

    @RequestMapping("/getM2HRelationById")
    public String getM2HRelationById(@RequestParam(name = "id", defaultValue = "-1") String id) {
        return serviceFacade.getMysql2HbaseRelationService().getM2HRelationById(id);
    }
}
