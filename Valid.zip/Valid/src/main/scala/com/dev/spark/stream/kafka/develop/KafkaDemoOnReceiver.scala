//package com.dev.spark.stream.kafka.develop
//
//import com.dev.spark.log.LoggerLevels
//import com.dev.spark.stream.kafka.util.HbaseUtil
//import org.apache.hadoop.hbase.client.Put
//import org.apache.hadoop.hbase.io.ImmutableBytesWritable
//import org.apache.spark.storage.StorageLevel
//import org.apache.spark.streaming.kafka.KafkaUtils
//import org.apache.spark.streaming.{Seconds, StreamingContext}
//import org.apache.spark.{HashPartitioner, SparkConf}
//
//object KafkaDemoOnReceiver {
//  def main(args: Array[String]) {
//    LoggerLevels.setLogLevels()
//    // zk集群,组,topics可以多个,线程数
//    val sparkConf = new SparkConf().setAppName("KafkaDemo").setMaster("local[2]")
//    val ssc = new StreamingContext(sparkConf, Seconds(5))
//    val hbaseConf = HbaseUtil.getConf()
//    val hbaseConn = HbaseUtil.getConn()
//    //    ssc.checkpoint("E:\\Valid\\output\\ck")
//    val topicMap = TOPIC.split(",").map((_, THREADS_NUM.toInt)).toMap
//    val data = KafkaUtils.createStream(ssc, KAFKA_ZOOKEEPER, GROUP_ID, topicMap, StorageLevel.MEMORY_AND_DISK_SER)
//
//
//    HbaseUtil.getTable(hbaseConn, TABLE_NAME)
//    val jobConf = HbaseUtil.getNewJobConf(hbaseConf, TABLE_NAME)
//    val value = data.map(data => {
//      val rowKey = data._2.toString
//      val put = new Put(rowKey.getBytes())
//      put.addColumn(TABLE_CF.getBytes(), "count".getBytes(), "1".getBytes())
//      (new ImmutableBytesWritable(), put)
//    })
//    value.foreachRDD(x => {
//      x.saveAsNewAPIHadoopDataset(jobConf)
//    })
//    ssc.start()
//    ssc.awaitTermination()
//  }
//}
