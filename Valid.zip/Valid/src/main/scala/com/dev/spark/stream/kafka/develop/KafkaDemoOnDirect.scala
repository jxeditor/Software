//package com.dev.spark.stream.kafka.develop
//
//import com.dev.spark.log.LoggerLevels
//import com.dev.spark.stream.kafka.util.HbaseUtil
//import kafka.serializer.StringDecoder
//import org.apache.hadoop.hbase.client.Put
//import org.apache.hadoop.hbase.io.ImmutableBytesWritable
//import org.apache.hadoop.hbase.mapreduce.TableInputFormat
//import org.apache.spark.{SparkConf, SparkContext}
//import org.apache.spark.streaming.{Seconds, StreamingContext}
//import org.apache.spark.streaming.kafka.{KafkaManager, KafkaUtils}
//
//object KafkaDemoOnDirect {
//
//  def main(args: Array[String]) {
//    LoggerLevels.setLogLevels()
//    // Create context with 2 second batch interval
//    val sparkConf = new SparkConf().setAppName("DirectKafkaWordCount")
//    sparkConf.setMaster("local[*]")
//    //    sparkConf.set("spark.streaming.kafka.maxRatePerPartition", "5")
//    //    sparkConf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
//
//    val hbaseConf = HbaseUtil.getConf()
//    val hbaseConn = HbaseUtil.getConn()
//    val ssc = new StreamingContext(sparkConf, Seconds(5))
//    val sc = new SparkContext(sparkConf)
//
//    sc.textFile("")
//
//    // Create direct kafka stream with brokers and topics
//    val topicsSet = TOPIC.split(",").toSet
//    val kafkaParams = Map[String, String](
//      "metadata.broker.list" -> BROKER,
//      "group.id" -> GROUP_ID
//      , "auto.offset.reset" -> "smallest"
//    )
//
//    val km = new KafkaManager(kafkaParams)
//    val messages = km.createDirectStream[String, String, StringDecoder, StringDecoder](
//      ssc, kafkaParams, topicsSet)
//
//    //    val messages = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topicsSet)
//    messages.foreachRDD(rdd => {
//      if (!rdd.isEmpty()) {
//        HbaseUtil.getTable(hbaseConn, TABLE_NAME)
//        val jobConf = HbaseUtil.getNewJobConf(hbaseConf, TABLE_NAME)
//        // 先处理消息
//        rdd.map(data => {
//          val rowKey = data._2.toString
//          val put = new Put(rowKey.getBytes())
//          put.addColumn(TABLE_CF.getBytes(), "count".getBytes(), "1".getBytes())
//          (new ImmutableBytesWritable(), put)
//        }).saveAsNewAPIHadoopDataset(jobConf)
//        // 再更新offsets
//        km.updateZKOffsets(rdd)
//      }
//    })
//
//    ssc.start()
//    ssc.awaitTermination()
//  }
//}
