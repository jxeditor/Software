package com.dev.spark

import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ArrayBuffer

object WordCount {

  def main(args: Array[String]): Unit = {
    //    LoggerLevels.setLogLevels()

    // 非常重要,是通向Spark集群的入口
    val conf = new SparkConf().setAppName("wc").setMaster("local")
    val sc = new SparkContext(conf)


    var list = Seq[Long]()

    list = list :+ 1L

    println(list)
    var temp = ""
    // textFile会产生两个RDD HadoopRDD -> MapPartitionsRDD
    val rdd = sc.textFile("E:\\Valid\\src\\main\\scala\\com\\dev\\spark\\test").cache()
      .map((1, _))
      .reduceByKey(_ + _).map(x => {
      x._2
    })
    //      .map(line => {
    //        var log = ""
    //        if (!line.endsWith("}")) {
    //          temp += line
    //        } else {
    //          log = temp + line
    //          temp = ""
    //        }
    //        log
    //      }).filter(!_.equals(""))

    println(rdd.collect().toList)
    // flatMap产生一个RDD MapPartitionsRDD
    //      .flatMap(_.split(" "))
    // map产生一个RDD MapPartitionsRDD
    //      .map((_, 1))
    //      .reduceByKey(_ + _)
    //      // .sortBy(_._2, false)
    //      .saveAsTextFile("E:\\Valid\\output\\wc")
    sc.stop()
  }
}