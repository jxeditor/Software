//package com.dev.spark.stream.kafka
//
//import com.dev.spark.stream.kafka.param.EnvironmentalKey
//
//package object util extends EnvironmentalKey {
//
//}
