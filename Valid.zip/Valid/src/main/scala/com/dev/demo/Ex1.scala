package com.dev.demo

import scala.collection.mutable

object Ex1 {
  def main(args: Array[String]): Unit = {
    val s = "2,3,,4"
    //val list = s.split(",").toList.map(_.toLong)
    //list

    val list1 = "1|2|3|".split("|").toList
    val list2 = "1|2|3|".split("|").toList
    val a = (true /: list1) {
      (x, y) => x && list2.contains(y)
    }
    a

    (1 /: list1) {
      (x, y) => 1
    }

    val sb = new StringBuilder(s)
    val value = "3"
    if (s.contains(value)) {
      sb.delete(s.indexOf(value), s.indexOf(value) + value.length)
      if (sb.indexOf(",,") != -1)
        sb.delete(sb.indexOf(",,"), sb.indexOf(",,") + 1)
      println(sb)
      if (sb.indexOf(",") == 0)
        sb.delete(sb.indexOf(","), sb.indexOf(",") + 1)
      println(sb)
    } else {
      println("error")
    }


    val map = new mutable.HashMap[String, String]()

    val time1 = System.currentTimeMillis()
    // 251358
    //    for (i <- 1 to 60000000) {
    //      print("$(\"#area\").html(\"<select class='form-control btn-default' id='unit' style='margin-right: 2.2em;'></select><select class='form-control btn-default' id='dep' style='margin-right: 2.2em;'></select><select class='form-control btn-default' id='draft' style='margin-right: 2.2em;'></select>\")")
    //    }
    val time2 = System.currentTimeMillis()
    for (i <- 1 to 60000000) {
      map.getOrElse("test", {
        print("$(\"#area\").html(\"<select class='form-control btn-default' id='unit' style='margin-right: 2.2em;'></select><select class='form-control btn-default' id='dep' style='margin-right: 2.2em;'></select><select class='form-control btn-default' id='draft' style='margin-right: 2.2em;'></select>\")")
      })
    }
    val time3 = System.currentTimeMillis()
    println()
    println("time1<" + (time2 - time1) + ">")
    println("time2<" + (time3 - time2) + ">")


  }
}
