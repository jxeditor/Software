//package com.dev.flink.stream.kafka.develop
//
//import java.util
//import java.util.Properties
//
//import com.dev.flink.stream.hbase.develop.HBASE_ZOOKEEPER
//import com.dev.flink.stream.kafka.entry.JsonDeserializationSchema
//import org.apache.flink.api.scala.hadoop.mapreduce.HadoopOutputFormat
//import org.apache.hadoop.hbase.mapreduce.TableOutputFormat
//import org.apache.hadoop.mapreduce.Job
////import com.dev.flink.stream.kafka.util.HbaseUtil
//import org.apache.flink.api.common.io.OutputFormat
//import org.apache.flink.api.java.tuple.Tuple2
//import org.apache.flink.configuration.Configuration
//import org.apache.flink.streaming.api.functions.sink.{RichSinkFunction, SinkFunction}
//import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
//import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010
//import org.apache.flink.streaming.api.scala._
//import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
//import org.apache.hadoop.hbase.client._
//import org.apache.hadoop.hbase.util.Bytes
//import org.json.JSONObject
//
///**
//  * 测试情况:
//  * onSink: 30w数据用时06分15秒
//  * onUtil: 30w数据用时15分10秒
//  * onFormat: 30w数据用时5分55秒
//  */
//object KakfaDemo {
//  def main(args: Array[String]): Unit = {
//    val pro = new Properties()
//    pro.put("bootstrap.servers", BROKER)
//    pro.put("group.id", GROUP_ID)
//    pro.put("zookeeper.connect", KAFKA_ZOOKEEPER)
//    val env = StreamExecutionEnvironment.getExecutionEnvironment
//    env.enableCheckpointing(500)
//
//    val topics = TOPIC.split(",")
//    val list = new util.ArrayList[String]()
//    topics.foreach(list.add(_))
//    val topicMsgSchame = new JsonDeserializationSchema
//    val Consumer010 = new FlinkKafkaConsumer010[String](
//      list, topicMsgSchame, pro
//    ).setStartFromEarliest().setCommitOffsetsOnCheckpoints(false)
//
//    val conf = HBaseConfiguration.create()
//    conf.set("hbase.zookeeper.quorum", HBASE_ZOOKEEPER)
//    conf.set("hbase.zookeeper.property.clientPort", "2181")
//    conf.set("hbase.defaults.for.version.skip", "true")
//    conf.set("mapred.output.dir", "hdfs://hadoop01:8020/demo")
//    conf.set(org.apache.hadoop.hbase.mapreduce.TableOutputFormat.OUTPUT_TABLE, "test1")
//    conf.set("bulk.flush.max.actions","1")
//    conf.setClass("mapreduce.job.outputformat.class",
//      classOf[org.apache.hadoop.hbase.mapreduce.TableOutputFormat[String]],
//      classOf[org.apache.hadoop.mapreduce.OutputFormat[String, Mutation]])
//
//    val kafkaStream = env.addSource(Consumer010)
//    val job = Job.getInstance(conf)
//    val hadoopOF = new HadoopOutputFormat[String, Mutation](new TableOutputFormat(), job)
//
//
//
//    //    val hbaseDs = kafkaStream.map(x => {
//    //      val result = new JSONObject(x)
//    //      val tuple2 = new Tuple2[String, String]
//    //      tuple2.setField(result.getString("value"), 0)
//    //      tuple2.setField("1", 1)
//    //      //      (result.getString("value"), "1")
//    //      tuple2
//    //
//    //      x
//    //    })
//    val hbaseDs = kafkaStream.map(x => {
//      val result = new JSONObject(x)
//      (result.getString("value"), result.getString("value"))
//    })
//
//    // hbaseDs.print()
//    val ds = hbaseDs.map(x => {
//      val put = new Put(Bytes.toBytes(x._1))
//      put.addColumn(Bytes.toBytes(TABLE_CF), Bytes.toBytes("l1"), Bytes.toBytes(x._2))
//      (x._1, put.asInstanceOf[Mutation])
//    })
//
//    ds.print()
//
//    ds.writeUsingOutputFormat(hadoopOF)
//    //    val tableOuputFormat = new OutputFormat[Tuple2[String, String]] {
//    //      var conn: Connection = null
//    //
//    //      override def configure(configuration: Configuration): Unit = {
//    //
//    //      }
//    //
//    //      override def open(i: Int, i1: Int): Unit = {
//    //        val conf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
//    //        conf.set("hbase.zookeeper.quorum", HBASE_ZOOKEEPER)
//    //        conf.set("hbase.zookeeper.property.clientPort", "2181")
//    //        conn = ConnectionFactory.createConnection(conf)
//    //      }
//    //
//    //      override def writeRecord(it: Tuple2[String, String]): Unit = {
//    //        val tableName = TableName.valueOf(TABLE_NAME)
//    //        val put = new Put(Bytes.toBytes(it.f0))
//    //        put.addColumn(Bytes.toBytes(TABLE_CF), Bytes.toBytes("count"), Bytes.toBytes(it.f1 + "---"))
//    //        conn.getTable(tableName).put(put)
//    //      }
//    //
//    //      override def close(): Unit = {
//    //        try {
//    //          if (conn != null) conn.close()
//    //        } catch {
//    //          case e: Exception => println(e.getMessage)
//    //        }
//    //      }
//    //    }
//
//
//    //      .map(x => {
//    //      val put = new Put((x._1).getBytes)
//    //      put.addColumn("info".getBytes, "count".getBytes, x._2.toString.getBytes)
//    //      HbaseUtil.put("test.demo_", put)
//    //    })
//
//
//    //      .addSink(new RichSinkFunction[(String, String)] {
//    //      var conn: Connection = null
//    //      var table: Table = null
//    //      var mutator: BufferedMutator = null
//    //
//    //      override def open(parameters: Configuration): Unit = {
//    //        val tableName = TableName.valueOf(TABLE_NAME)
//    //        val conf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
//    //        conf.set("hbase.zookeeper.quorum", HBASE_ZOOKEEPER)
//    //        conf.set("hbase.zookeeper.property.clientPort", "2181")
//    //        conn = ConnectionFactory.createConnection(conf)
//    //        table = conn.getTable(tableName)
//    //        mutator = conn.getBufferedMutator(new BufferedMutatorParams(tableName)
//    //          .writeBufferSize(10 * 1024 * 1024)
//    //        )
//    //      }
//    //
//    //      override def invoke(value: (String, String), context: SinkFunction.Context[_]): Unit = {
//    //        val put = new Put(Bytes.toBytes(value._1))
//    //        //        put.addColumn(Bytes.toBytes(TABLE_CF), Bytes.toBytes("count"), Bytes.toBytes(value._2.toString().replace("---", "")))
//    //        put.addColumn(Bytes.toBytes(TABLE_CF), Bytes.toBytes("count"), Bytes.toBytes(value._2 + "---"))
//    //        put.addColumn(Bytes.toBytes(TABLE_CF), Bytes.toBytes("time"), Bytes.toBytes(System.currentTimeMillis()))
//    //        mutator.mutate(put)
//    //        mutator.flush()
//    //      }
//    //
//    //      override def close(): Unit = {
//    //        try {
//    //          if (table != null) table.close()
//    //          if (mutator != null) mutator.close()
//    //          if (conn != null) conn.close()
//    //        } catch {
//    //          case e: Exception => println(e.getMessage)
//    //        }
//    //      }
//    //    })
//
//
//    env.execute()
//  }
//}
