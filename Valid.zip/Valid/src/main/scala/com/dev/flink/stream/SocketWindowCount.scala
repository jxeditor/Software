//package com.dev.flink.stream
//
//import org.apache.flink.api.java.utils.ParameterTool
//import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
//import org.apache.flink.streaming.api.scala._
//import org.apache.flink.streaming.api.windowing.time.Time
//
//object SocketWindowCount {
//  def main(args: Array[String]): Unit = {
////    val hostname = try {
////      ParameterTool.fromArgs(args).get("hostname", "localhost")
////    } catch {
////      case e: Exception => {
////        System.err.println("请输入用户名,--hostname <hostname>")
////        return
////      }
////    }
////
////    val port = try {
////      ParameterTool.fromArgs(args).getInt("port")
////    } catch {
////      case e: Exception => {
////        System.err.println("请输入主机名和端口,--hostname <hostname> --port <port>")
////        return
////      }
////    }
//
//
//
//    val senv = StreamExecutionEnvironment.getExecutionEnvironment
//    val ds = senv.socketTextStream("hadoop01", 9999, '\n')
//
//    val wordCounts = ds.flatMap(_.split(" "))
//      .map(WordWithCount(_, 1))
//      .keyBy("word")
//      .timeWindow(Time.seconds(5), Time.seconds(1))
//      .sum("count")
//
//    wordCounts.print().setParallelism(1)
//    println(wordCounts)
//
//    senv.execute("Socket Window WordCount")
//  }
//
//  case class WordWithCount(word: String, count: Long)
//
//}
