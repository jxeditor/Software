//package com.dev.flink.stream.graph.develop.endpoint
//
//import com.dev.flink.stream.graph.template.EndPoint
//import org.apache.flink.api.scala._
//import org.apache.flink.streaming.api.scala.DataStream
//
//class AEndPoint(name: String) extends EndPoint[String]{
//  override def process(dataStream: DataStream[String]): Unit = {
//    println(s"$name")
//    dataStream.map(x => "AAAAAEndPoint ===>"+x).print()
//  }
//}
