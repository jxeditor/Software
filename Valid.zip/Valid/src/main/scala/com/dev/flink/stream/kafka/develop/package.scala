//package com.dev.flink.stream.kafka
//
//import com.dev.flink.stream.kafka.param.EnvironmentalKey
//
//package object develop extends EnvironmentalKey {
//
//}
