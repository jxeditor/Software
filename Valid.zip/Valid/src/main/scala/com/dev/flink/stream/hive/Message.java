//package com.dev.flink.stream.hive;
//
//public class Message {
//    private String topic;
//    private int partition;
//    private int offset;
//    private String msg;
//
//    public Message(String topic, int partition, int offset, String msg) {
//        this.topic = topic;
//        this.partition = partition;
//        this.offset = offset;
//        this.msg = msg;
//
//    }
//
//    public String getTopic() {
//        return topic;
//    }
//
//    public void setTopic(String topic) {
//        this.topic = topic;
//    }
//
//    public int getPartition() {
//        return partition;
//    }
//
//    public void setPartition(int partition) {
//        this.partition = partition;
//    }
//
//    public int getOffset() {
//        return offset;
//    }
//
//    public void setOffset(int offset) {
//        this.offset = offset;
//    }
//
//    public String getMsg() {
//        return msg;
//    }
//
//    public void setMsg(String msg) {
//        this.msg = msg;
//    }
//
//    @Override
//    public String toString() {
//        return "Message{" +
//                "topic='" + topic + '\'' +
//                ", partition=" + partition +
//                ", offset=" + offset +
//                ", msg='" + msg + '\'' +
//                '}';
//    }
//}
