//package com.dev.flink.stream.graph.template
//
//trait Point {}
