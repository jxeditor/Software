//package com.dev.flink.stream.hbase
//
//import com.dev.flink.stream.hbase.param.EnvironmentalKey
//
//package object util extends EnvironmentalKey{
//
//}
