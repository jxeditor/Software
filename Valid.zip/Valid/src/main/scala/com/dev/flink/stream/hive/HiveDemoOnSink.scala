//package com.dev.flink.stream.hive
//
//import java.util.Properties
//
//import org.apache.flink.api.common.JobID
//import org.apache.flink.api.common.typeutils.TypeSerializer
//import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
//import org.apache.flink.streaming.connectors.fs.bucketing.{BucketingSink, DateTimeBucketer}
//import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010
//import org.apache.hadoop.conf.Configuration
//import org.apache.flink.api.scala._
//import org.apache.flink.metrics.MetricGroup
//import org.apache.flink.runtime.execution.Environment
//import org.apache.flink.runtime.query.TaskKvStateRegistry
//import org.apache.flink.runtime.state.ttl.TtlTimeProvider
//import org.apache.flink.runtime.state._
//import org.apache.flink.runtime.state.filesystem.FsStateBackend
//import org.apache.flink.streaming.api.environment.CheckpointConfig.ExternalizedCheckpointCleanup
//import org.json.JSONObject
//
//import scala.collection.convert.WrapAsJava._
//
//object HiveDemoOnSink {
//  def main(args: Array[String]): Unit = {
//    val properties = new Properties()
//    properties.setProperty("bootstrap.servers", "hadoop03:9092")
//    properties.setProperty("group.id", "test")
//    properties.setProperty("auto.offset.reset", "latest")
//
//    val consumer010 = new FlinkKafkaConsumer010[String](
//      "test",
//      //      List("test1","test2"),
//      new JsonDeserializationSchema(),
//      properties
//    ).setStartFromLatest()
//
//    val senv = StreamExecutionEnvironment.getExecutionEnvironment
//    senv.enableCheckpointing(500)
//    senv.setStateBackend(new FsStateBackend("hdfs:///flink/checkpoints"))
//    val conf = senv.getCheckpointConfig
//    conf.enableExternalizedCheckpoints(ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION)
//    conf.enableExternalizedCheckpoints(ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION)
//
//    val dataStream = senv.addSource(consumer010)
//
//    val configuration = new Configuration()
//    configuration.set("fs.defaultFS", "hdfs://hadoop01:8020")
//    val bucketingSink = new BucketingSink[Message]("/user/hive/warehouse/user_test_orc").setBucketer(
//      new DateTimeBucketer[Message]("'c_date='yyyy-MM-dd")
//    ).setWriter(
//      new OrcWriter[Message](classOf[Message])
//    ).setBatchSize(1024 * 10).setFSConfig(configuration)
//
//    val ds = dataStream.map(data => {
//      val json = new JSONObject(data.toString)
//      val topic = json.get("topic").toString
//      val partition = json.get("partition").toString.toInt
//      val offset = json.get("offset").toString.toInt
//      new Message(topic, partition, offset, json.toString())
//    })
//
//    ds.print()
//
//    ds.addSink(bucketingSink)
//    senv.execute()
//  }
//}
//
///**
//  * *
//  * CREATE TABLE user_test_orc(
//  * topic string,
//  * partition int,
//  * offset int,
//  * msg string)
//  * partitioned BY (c_date string)
//  * ROW FORMAT serde 'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
//  * STORED AS inputformat 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
//  * outputformat 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat';
//  *
//  *
//  *
//  */
