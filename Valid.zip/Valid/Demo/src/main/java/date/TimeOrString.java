package date;

import junit.framework.Assert;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class TimeOrString {
    public static void main(String[] args) {
//        Long millisecond = Instant.now().toEpochMilli();
//        Long second = Instant.now().getEpochSecond();
//
//        System.out.println(36000*3+35000+8000+18000);
//        Long s = 1_0000_0000L;
//        System.out.println(s);
        Long a = Long.valueOf("1560323472875");
        Long b = Long.valueOf("1560323485723");
        System.out.println(converTimeToString(b - a, "1"));
        System.out.println(converTimeToString(a, "0"));
        System.out.println(converTimeToString(b, "0"));
    }

    public static String converTimeToString(Long time, String flag) {
        Assert.assertNotNull(time);
        DateTimeFormatter ftf = null;

        if (flag == "0")
            ftf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        else
            ftf = DateTimeFormatter.ofPattern("mm:ss");
        return ftf.format(LocalDateTime.ofInstant(Instant.ofEpochMilli(time), ZoneId.systemDefault()));
    }

    public static Long converTimeToLong(String time) {
        Assert.assertNotNull(time);
        DateTimeFormatter ftf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime parse = LocalDateTime.parse(time, ftf);
        return LocalDateTime.from(parse).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }
}
