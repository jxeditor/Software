package test;



public class Yys {
    public static void main(String[] args) {
        System.out.println(effectHit(0.25, 1.0));
        System.out.println(effectResist(1.0, 0.5));
    }

    /**
     * @param skillHit 基础命中
     * @param panelHit 面板命中
     * @return 实际命中概率
     */
    public static double effectHit(double skillHit, double panelHit) {
        return skillHit * (1 + panelHit);
    }

    /**
     * @param hit    概率命中
     *               取值为1.0到无穷大: effectHit返回的值大于1.0,否则都按1.0计算
     *               取值为0: 技能没有命中,自然不会被抵抗
     * @param resist 面板抵抗<暂时不考虑技能加效果抵抗的情况>
     * @return 抵抗概率
     */
    public static double effectResist(double hit, double resist) {
        return 1 - hit / (1 + resist);
    }
}
