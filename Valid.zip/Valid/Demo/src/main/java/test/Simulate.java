package test;

import org.json.JSONObject;

public class Simulate {
    public static void main(String[] args) {
        String s = "{'after':{ref:'-7149754067087',question_id:'-7145933891076',course_id:'-9999995610815',c_time:'2019-02-23 09:59:09',reference_id:null,operate_time:'2019-02-23 09:59:17',local_status:2,is_quote:0}}";
        JSONObject jsonObject = new JSONObject(s);
        JSONObject result = jsonObject.getJSONObject("after");
        if (result.getInt("local_status") == 2) {
            // 删除
        } else {
            // 更新
        }
    }
}
