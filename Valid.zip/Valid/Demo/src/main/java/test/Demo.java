package test;

import java.util.HashMap;
import java.util.Random;

public class Demo {
    public static void main(String[] args) {
        String s = "0000,111,1112|111,222,333";
        String[] split = s.split("\\|");
        for (String x : split) {
            System.out.println(x);
        }


        HashMap<Integer, String> map = new HashMap<>();
        map.put(1, "测试1");
        map.put(2, "测试2");
        map.put(3, "测试3");
        map.put(4, "测试4");
        map.put(5, "测试5");
        map.put(6, "测试6");
        map.put(7, "测试7");
        map.put(8, "测试8");
        map.put(9, "测试9");
        map.put(10, "测试10");
        map.put(11, "测试11");
        map.put(12, "测试12");
        map.put(13, "测试13");
        map.put(14, "测试14");
        map.put(15, "测试15");
        map.put(16, "测试16");
        map.put(17, "测试17");
        map.put(18, "测试18");
        map.put(19, "测试19");
        map.put(20, "测试20");
        map.put(21, "测试21");
        map.put(22, "测试22");
        map.put(23, "测试23");
        map.put(24, "测试24");
        map.put(25, "测试25");
        map.put(26, "测试26");
        map.put(27, "测试27");

        int i = new Random().nextInt(map.size()) + 1;

        // 一重
        for (int j = 0; j < 1; j++) {
            if (i < 10) {
                i = randomCount(i, 3, 1, 27);
            } else {
                break;
            }
        }
        if (i < 10) {
            i = new Random().nextInt(9) + 1;
        }
        System.out.println(map.get(i));
    }

    public static int randomCount(int v, int count, int start, int range) {
        for (int i = 0; i < count; i++) {

        }
        return new Random().nextInt(range) + start;
    }
}
