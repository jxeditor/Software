define("entityResourceDisplayer", ["jquery", "resource"], function (a, e) {
    var p = function (n, d) {
        d.addClass("resource-hint");
        var m = d.find(".active").remove().find("a").addClass("resource-label"),
            l = a('\x3cspan class\x3d"resource-icon"\x3e\x3c/span\x3e').addClass(e.types[n.type].icon),
            f = a('\x3cspan class\x3d"glyphicon glyphicon-remove remove"\x3e\x3c/span\x3e');
        d.find(".wiki").first().remove();
        return a("\x3cdiv\x3e\x3c/div\x3e").append(l).append(document.createTextNode(" ")).append(m).append(document.createTextNode(" ")).append(f).add(d)
    };
    e.displayers.doc = function (e) {
        var d = a.Deferred();
        a.post(XWiki.currentDocument.getURL("get"), {
            language: a("html").attr("lang"),
            xpage: "hierarchy_reference",
            reference: e.reference,
            limit: 5
        }).done(function (m) {
            m = a(m);
            m.hasClass("breadcrumb") ? d.resolve(p(e, m)) : d.reject()
        }).fail(function () {
            d.reject()
        });
        return d.promise()
    };
    e.displayers.attach = function (n) {
        var d = a.Deferred(), m = e.convertResourceReferenceToEntityReference(n);
        a.post(XWiki.currentDocument.getURL("get"), {
            language: a("html").attr("lang"), xpage: "hierarchy_reference",
            reference: XWiki.Model.serialize(m.parent), limit: 4
        }).done(function (e) {
            var f = a('\x3cli class\x3d"attachment active"\x3e\x3ca\x3e\x3c/a\x3e\x3c/li\x3e'),
                k = (new XWiki.Document(m.parent)).getURL("download") + "/" + encodeURIComponent(m.name);
            f.find("a").attr("href", k).text(m.name);
            e = a(e);
            e.find(".active").removeClass("active").after(f);
            e.hasClass("breadcrumb") ? d.resolve(p(n, e)) : d.reject()
        }).fail(function () {
            d.reject()
        });
        return d.promise()
    }
});
define("entityResourcePickerTranslationKeys", [], ["select", "doc.title", "attach.title"]);
define("entityResourcePicker", ["jquery", "resource", "modal", "l10n!entityResourcePicker", "tree"], function (a, e, p, n) {
    var d = function (b) {
        return a(document.createElement("div")).attr(a.extend({
            "class": "ckeditor-tree jstree-no-links",
            "data-edges": !0,
            "data-finder": !0,
            "data-icons": !0,
            "data-responsive": !0
        }, b))
    }, m = function (b, c) {
        var h = b.find(".ckeditor-tree"), k = b.find(".modal-footer .btn-primary"), e = function (b) {
            b = b.get_selected(!0);
            for (var a = 0; a < b.size(); a++) if (!c.canSelect(b[a])) return !1;
            return 0 < b.size()
        };
        b.on("shown.bs.modal",
            function (g) {
                var d = c.openToNodeId;
                "string" === typeof d && d !== b.data("openTo") ? b.data("openTo", d) : d = !1;
                g = a.jstree.reference(h);
                g ? d && (g.deselect_all(), g.close_all(), g.openTo(d)) : g = h.xtree({core: {multiple: "true" === h.data("multiple")}}).one("ready.jstree", function (b, c) {
                    d && c.instance.openTo(d)
                }).on("changed.jstree", function (b, c) {
                    k.prop("disabled", !e(c.instance))
                }).on("dblclick", ".jstree-anchor", function (b) {
                    e(a.jstree.reference(this)) && k.click()
                })
            });
        k.click(function () {
            b.modal("hide");
            var k = a.jstree.reference(h);
            c.select(k.get_selected(!0))
        });
        c.open = function (c) {
            this.openToNodeId = c;
            b.modal()
        };
        return c
    }, l = function (b) {
        var c = b.text, a, h = b.id.indexOf(":");
        a = b.id.substr(0, h);
        b = b.id.substr(h + 1);
        a = XWiki.Model.resolve(b, XWiki.EntityType.byName(a));
        return {title: c, reference: a}
    }, f = function (b) {
        return XWiki.EntityType.getName(b.type) + ":" + XWiki.Model.serialize(b)
    }, k = function (b) {
        var c = b.extractReference(XWiki.EntityType.DOCUMENT);
        c || (c = b.extractReference(XWiki.EntityType.SPACE), c || (b = b.extractReference(XWiki.EntityType.WIKI) ||
            new XWiki.WikiReference(XWiki.currentWiki), c = new XWiki.EntityReference("Main", XWiki.EntityType.SPACE, b)), c = new XWiki.EntityReference("WebHome", XWiki.EntityType.DOCUMENT, c));
        return c
    }, r = function (b, c) {
        var a = c.extractReference(b);
        return a ? f(a) : b === XWiki.EntityType.DOCUMENT ? f(k(c)) : b === XWiki.EntityType.ATTACHMENT ? "attachments:" + XWiki.Model.serialize(k(c)) : f(c)
    }, g = function (b, c) {
        var a = m(b, {
            canSelect: function (b) {
                return (b.data || {}).type === c.entityType
            }, select: function (b) {
                c.select(b.map(l))
            }
        });
        c.open = function (b) {
            a.open(r(XWiki.EntityType.byName(c.entityType),
                b))
        };
        return c
    }, t = function (b) {
        return a.extend({}, b, {
            reference: e.convertEntityReferenceToResourceReference(b.reference),
            entityReference: b.reference
        })
    }, u = function (b, c) {
        var a = g(b, {
            entityType: e.types[c.resourceType].entityType, select: function (b) {
                c.select(b.map(t))
            }
        });
        c.open = function (b) {
            a.open(e.convertResourceReferenceToEntityReference(b))
        };
        return c
    }, q = {
        doc: (new XWiki.Document("DocumentTree", "XWiki")).getURL("get", a.param({
            outputSyntax: "plain", language: a("html").attr("lang"), showAttachments: !1, showTranslations: !1,
            showWikis: !0
        })),
        attach: (new XWiki.Document("DocumentTree", "XWiki")).getURL("get", a.param({
            outputSyntax: "plain",
            language: a("html").attr("lang"),
            showTranslations: !1,
            showWikis: !0
        }))
    }, h = function (b, c) {
        var h = p.createModal({
            "class": "entity-resource-picker-modal",
            title: c,
            content: d({"data-url": q[b]}),
            acceptLabel: n.get("select")
        }), k = u(h, {resourceType: b});
        e.pickers[b] = function (b) {
            var c = a.Deferred();
            k.select = function (b) {
                c.resolve(b[0])
            };
            k.open(b);
            return c.promise()
        }
    };
    "function" === typeof a.fn.xtree && (h("doc",
        n.get("doc.title")), h("attach", n.get("attach.title")))
});
define("entityResourceSuggesterTranslationKeys", [], ["doc.placeholder", "attach.placeholder"]);
define("entityResourceSuggester", ["jquery", "resource", "l10n!entityResourceSuggester"], function (a, e, p) {
    var n = function (k, e, g, f) {
        a.post((new XWiki.Document("SuggestSolrService", "XWiki")).getURL("get"), {
            outputSyntax: "plain",
            language: a("html").attr("lang"),
            query: k.join("\n"),
            input: e,
            nb: 8
        }).done(function (a) {
            if (a.documentElement) {
                a = a.getElementsByTagName("rs");
                for (var k = [], h = 0; h < a.length; h++) k.push(d(a.item(h), f));
                g.resolve(k)
            } else g.resolve([])
        }).fail(function () {
            g.resolve([])
        })
    }, d = function (a, d) {
        var g, f,
            n = a.childNodes[0].nodeValue;
        (g = a.getAttribute("type")) ? (f = a.getAttribute("id"), g = XWiki.Model.resolve(f, XWiki.EntityType.byName(g)), f = a.getAttribute("info")) : (g = a.getAttribute("info"), g = XWiki.Model.resolve(g, XWiki.EntityType.DOCUMENT), f = m(g), d === XWiki.EntityType.ATTACHMENT && (g = new XWiki.AttachmentReference(n, g)));
        return {reference: e.convertEntityReferenceToResourceReference(g), entityReference: g, title: n, location: f}
    }, m = function (a) {
        a = a.getReversedReferenceChain();
        a[0].type === XWiki.EntityType.WIKI && a[0].name ===
        XWiki.currentWiki && a.shift();
        return a.map(function (a) {
            return a.name
        }).join(" / ")
    }, l = function (k) {
        var d = a('\x3cspan class\x3d"resource-label"\x3e\x3cspan class\x3d"resource-icon"\x3e\x3c/span\x3e \x3c/span\x3e\x3cspan class\x3d"resource-hint"\x3e\x3c/span\x3e');
        d.find(".resource-icon").addClass(e.types[k.reference.type].icon);
        d.first().append(document.createTextNode(k.title)).next().html(k.location);
        d.last().text(function (a, d) {
            return " / " === d.substr(0, 3) ? d.substr(3) : d
        });
        return d
    }, f = /[+\-!(){}\[\]\^"~*?:\\]+/;
    e.types.doc.placeholder = p.get("doc.placeholder");
    e.suggesters.doc = {
        retrieve: function (d) {
            var e = a.Deferred(), g = ["q\x3d__INPUT__", "fq\x3dtype:DOCUMENT"];
            (d = d.reference.trim()) ? (g.push("qf\x3dtitle^2 name"), f.test(d) || (g[0] = "q\x3d(__INPUT__)^2 __INPUT__*")) : (d = "*:*", g.push("sort\x3ddate desc"));
            n(g, d, e, XWiki.EntityType.DOCUMENT);
            return e.promise()
        }, display: l
    };
    e.types.attach.placeholder = p.get("attach.placeholder");
    e.suggesters.attach = {
        retrieve: function (d) {
            var e = a.Deferred(), g = ["q\x3d__INPUT__", "fq\x3dtype:ATTACHMENT"];
            (d = d.reference.trim()) ? (g.push("qf\x3dfilename"), f.test(d) || (g[0] = "q\x3d(__INPUT__)^2 __INPUT__*")) : (d = "*:*", g.push("sort\x3dattdate_sort desc"));
            n(g, d, e, XWiki.EntityType.ATTACHMENT);
            return e.promise()
        }, display: l
    }
});
define("resourceTranslationKeys", [], "attach.label attach.placeholder data.label doc.label doc.placeholder icon.label mailto.label mailto.placeholder path.label path.placeholder unc.label unc.placeholder unknown.label url.label url.placeholder user.label user.placeholder".split(" "));
define("resource", ["l10n!resource"], function (a) {
    var e = {
        attach: {
            label: a.get("attach.label"),
            icon: "glyphicon glyphicon-paperclip",
            placeholder: a.get("attach.placeholder"),
            entityType: "attachment"
        },
        data: {
            label: a.get("data.label"),
            icon: "glyphicon glyphicon-briefcase",
            placeholder: "image/png;base64,AAAAAElFTkSuQmCC"
        },
        doc: {
            label: a.get("doc.label"),
            icon: "glyphicon glyphicon-file",
            placeholder: a.get("doc.placeholder"),
            allowEmptyReference: !0,
            entityType: "document"
        },
        icon: {
            label: a.get("icon.label"), icon: "glyphicon glyphicon-flag",
            placeholder: "help"
        },
        mailto: {
            label: a.get("mailto.label"),
            icon: "glyphicon glyphicon-envelope",
            placeholder: a.get("mailto.placeholder")
        },
        path: {label: a.get("path.label"), icon: "glyphicon glyphicon-road", placeholder: a.get("path.placeholder")},
        unc: {label: a.get("unc.label"), icon: "glyphicon glyphicon-hdd", placeholder: a.get("unc.placeholder")},
        unknown: {label: a.get("unknown.label"), icon: "glyphicon glyphicon-question-sign", placeholder: ""},
        url: {label: a.get("url.label"), icon: "glyphicon glyphicon-globe", placeholder: a.get("url.placeholder")},
        user: {label: a.get("user.label"), icon: "glyphicon glyphicon-user", placeholder: a.get("user.placeholder")}
    }, p = ["wiki", "space", "doc", "attach"];
    return {
        types: e,
        pickers: {},
        suggesters: {},
        displayers: {},
        convertEntityReferenceToResourceReference: function (a, d) {
            d = d || XWiki.currentDocument.getDocumentReference();
            var e = p[a.type], l;
            l = a.relativeTo(d);
            var f;
            f = a;
            for (var k = l; k.parent;) f = f.parent, k = k.parent;
            if (f.parent && f.parent.type === f.type) if (a.type === XWiki.EntityType.DOCUMENT) l = "." + XWiki.Model.serialize(l); else {
                do f =
                    f.parent; while (f.parent && f.parent.type === f.type);
                l = f.parent;
                delete f.parent;
                k = XWiki.Model.serialize(a);
                f.parent = l;
                l = k
            } else l = XWiki.Model.serialize(l);
            return {type: e, typed: !0, reference: l}
        },
        convertResourceReferenceToEntityReference: function (a, d) {
            d = d || XWiki.currentDocument.getDocumentReference();
            var m = XWiki.EntityType.byName(e[a.type].entityType);
            return XWiki.Model.resolve(a.reference, m, d)
        }
    }
});
define("resourcePicker", ["jquery", "resource", "bootstrap3-typeahead"], function (a, e) {
    var p = function (h) {
        var b = e.types[h] || {label: h, icon: "glyphicon glyphicon-question-sign"};
        this.find(".input-wrapper").attr("class", "input-group").children(".input-group-btn").show();
        var c = this.find(".resourceTypes");
        if (1 === c.children().length) {
            var d = c.next(".resourceType");
            d.prependTo(d.parent()).nextAll().show()
        }
        a('\x3cli\x3e\x3ca href\x3d"#"\x3e\x3cspan class\x3d"icon"\x3e\x3c/span\x3e\x3c/a\x3e\x3c/li\x3e').appendTo(c).find("a").attr({
            "data-id": h,
            "data-placeholder": b.placeholder
        }).children(".icon").addClass(b.icon).after(document.createTextNode(" " + b.label))
    }, n = function (h) {
        h.on("click", ".resourceTypes a", d).on("changeResourceType", t).on("changeResourceType", u);
        var b = h.find("button.resourceType");
        b.click(m);
        var c = h.find(".resourceDisplay"), e = h.find("input.resourceReference");
        c.on("click", ".remove", function (b) {
            c.addClass("hidden").empty();
            e.change()
        });
        c.on("click", "a", function (b) {
            b.preventDefault()
        });
        e.change(function (a) {
            c.hasClass("hidden") &&
            h.prev("input").val(b.val() + ":" + e.val())
        });
        h.on("keydown", "input.resourceReference", function (b) {
            13 === b.which && a(b.target).change()
        });
        h.prev("input").on("beforeGetValue", function () {
            e.change()
        })
    }, d = function (h) {
        h.preventDefault();
        h = a(this);
        var b = h.closest(".resourcePicker"), c = b.find("button.resourceType"), d = c.val(), f = h.attr("data-id");
        if (f !== d) {
            c.val(f);
            c.attr("title", h.text().trim());
            var g = "function" !== typeof e.pickers[f];
            /**c.prop("disabled",g);g&&c.attr("disabled","disabled");**/c.find(".icon").attr("class",
                h.find(".icon").attr("class"));
            b.find(".resourceReference").attr("placeholder", h.attr("data-placeholder"));
            b.trigger("changeResourceType", {oldValue: d, newValue: f})
        }
    }, m = function (h) {
        h = a(this);
        var b = h.closest(".resourcePicker"), c = k(b.prev("input"));
        c.type !== h.val() && (c = {type: h.val(), reference: b.find("input.resourceReference").val()});
        if(c.type == 'url'){
            console.log("url")
        }else if(c.type == 'mailto'){
            console.log("mail")
        }else{
            e.pickers[c.type](c).done(a.proxy(l, b))
        }
    }, l = function (a) {
        this.prev("input").val(a.reference.type + ":" + a.reference.reference).trigger("selectResource", a)
    }, f = function (d, b) {
        b =
            b || {reference: k(a(d.target))};
        var c = a(d.target).nextAll("div.resourcePicker").first();
        r(c, b.reference.type);
        g(c, b.reference)
    }, k = function (a) {
        var b = a.val(), c = b.indexOf(":"), d = b.substr(0, c), b = b.substr(c + 1);
        0 === d.length && (0 === b.length && (d = a.next(".resourcePicker").find(".resourceTypes a").first().attr("data-id")), d = d || "unknown");
        return {type: d, reference: b, isNew: 0 > c && 0 === b.length}
    }, r = function (d, b) {
        var c = d.find(".resourceType");
        b !== c.val() && (c = d.find("a").filter(function () {
            return a(this).attr("data-id") ===
                b
        }), 0 === c.length && (p.call(d, b), c = d.find("a").filter(function () {
            return a(this).attr("data-id") === b
        })), c.click())
    }, g = function (a, b) {
        var c = a.find(".resourceReference"), d = a.find(".resourceDisplay"), f = e.displayers[b.type];
        "function" === typeof f && !b.isNew && (0 < b.reference.length || e.types[b.type].allowEmptyReference) ? (c.val(""), d.empty().addClass("loading").removeClass("hidden"), f(b).done(function (a) {
            d.empty().removeClass("loading").attr({
                "data-resourceType": b.type,
                "data-resourceReference": b.reference
            }).append(a).removeClass("hidden")
        }).fail(function () {
            c.val(b.reference);
            d.addClass("hidden")
        })) : (d.addClass("hidden").empty(), c.val(b.reference))
    }, t = function (d, b) {
        var c = a(this), e = c.find(".resourceDisplay");
        e.attr("data-resourceType") !== b.newValue || e.is(":empty") ? (e.addClass("hidden"), c.find("input.resourceReference").change()) : (e.removeClass("hidden"), c.prev("input").val(e.attr("data-resourceType") + ":" + e.attr("data-resourceReference")))
    }, u = function (d, b) {
        var c = a(this), f = c.find("input.resourceReference");
        f.typeahead("destroy");
        var g = e.suggesters[b.newValue];
        g ? f.keydown(q).typeahead({
            afterSelect: a.proxy(l,
                c), delay: 500, displayText: function (a) {
                var b = new String(a.reference.reference);
                b.__resource = a;
                return b
            }, highlighter: !g.display || function (a) {
                return g.display(a.__resource)
            }, matcher: function (a) {
                return !0
            }, minLength: 0, sorter: function (a) {
                return a
            }, source: function (a, c) {
                g.retrieve({type: b.newValue, reference: a}).done(c)
            }
        }) : f.off("keydown", q)
    }, q = function (d) {
        (27 === d.which || 13 === d.which) && 0 < a(this).next(".dropdown-menu").filter(":visible").length && d.stopPropagation()
    };
    a.fn.resourcePicker = function (d) {
        return this.each(function () {
            if (!a(this).next().is("div.resourcePicker")) {
                var b =
                        a(this), c = d, c = c || {},
                    e = a('\x3cdiv class\x3d"resourcePicker"\x3e\x3cdiv class\x3d"input-group"\x3e\x3cinput type\x3d"text" class\x3d"resourceReference" /\x3e\x3cdiv class\x3d"input-group-btn"\x3e\x3cbutton type\x3d"button" class\x3d"resourceType btn btn-default"\x3e\x3cspan class\x3d"icon"\x3e\x3c/button\x3e\x3cbutton type\x3d"button" class\x3d"btn btn-default dropdown-toggle" data-toggle\x3d"dropdown"\x3e\x3cspan class\x3d"caret"\x3e\x3c/span\x3e\x3c/button\x3e\x3cul class\x3d"resourceTypes dropdown-menu dropdown-menu-right"\x3e\x3c/ul\x3e\x3c/div\x3e\x3c/div\x3e\x3cdiv class\x3d"resourceDisplay"\x3e\x3c/div\x3e\x3c/div\x3e');
                b.on("selectResource", f).hide().after(e);
                c = a(b).attr("data-resourceTypes") || c.resourceTypes || [];
                "string" === typeof c && (c = c.split(/\s*,\s*/));
                if (0 === c.length) e.find(".input-group").attr("class", "input-wrapper").children(".input-group-btn").hide(); else if (1 === c.length) {
                    var g = e.find(".resourceType");
                    g.appendTo(g.parent()).prevAll().hide()
                }
                c.forEach(p, e);
                n(e);
                b.trigger("selectResource")
            }
        })
    }
});
define("resourcePicker.bundle", ["resourcePicker", "entityResourcePicker", "entityResourceSuggester", "entityResourceDisplayer"], function () {
});