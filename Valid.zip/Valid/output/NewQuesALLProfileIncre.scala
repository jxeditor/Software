package com.etiantian.bigdata

import java.io.{File, FileInputStream}
import java.time.LocalDate
import java.util.Properties

import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import org.elasticsearch.spark.sql._


/**
  * 新旧题库试题的教材，版本，学科，年级，难度，正确率，标准时长，年份，使用量，年份，学段,选项,卷面题型，来源,收藏量的等属性
  * 新题库是在oracle录入，表名是EX_EXAM_QUESTION_INFO_oracle，导入至数校的question_info_mysql
  * question_info_mysql表里question_id > 1亿为新题，当两表起冲突时，以question_info_mysql为主
  * 学段只有试题组的，组试题的body进行合并，暂时程序除去组试题的部分
  * 来源：1是高考，2是中考，3是其他
  * collect_set去除重复元素；collect_list不去除重复元素
  * 去掉oracle表中的body以及相关联的字段
  * 改写es从一天一个版本变成一个版本添加的方式
  */
object NewQuesALLProfileIncre {
  val logger = LogManager.getLogger("NewQuesALLProfileIncre")
  def main(args: Array[String]): Unit = {
    val configFile = new File(args(0))
    if(!configFile.exists()){
      logger.error("Missing config.properties file!")
    }

    val properties = new Properties()
    properties.load(new FileInputStream(configFile))

    val conf = new SparkConf().setAppName("common-resource:NewQuesALLProfileIncre")
      .set("es.index.auto.create", "true")
      .set("es.nodes", properties.getProperty("es.nodes"))
      .set("es.port", properties.getProperty("es.port"))

    HbaseUtil.init(properties)
    val job = HbaseUtil.create(TableName.valueOf("test_ques_profile"), "tol")


    val sc = new SparkContext(conf)

    val sqlContext = new HiveContext(sc)

//    val lastday = if (args.length>=2) args(1) else LocalDate.now().plusDays(-2).toString
//    println("--------------------------------" + lastday + "--------------------------------")
//    val yesterday = if (args.length>=3) args(2) else LocalDate.now().plusDays(-1).toString
//    println("--------------------------------" + yesterday + "--------------------------------")

//    sqlContext.setConf("hive.exec.dynamic.partition", "true")
//    sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")

    //question_id大于200000000的试题，相减后为同一道题,得到两属性
    def realQuesId(quesId: Long)={
      if (quesId > 200000000)
        quesId - 200000000
      else
        quesId
    }
    sqlContext.udf.register("realQuesId",realQuesId _)

    def mkString(seq:Seq[Unit])={
      seq.mkString(",")
    }
    sqlContext.udf.register("mkString",mkString _)


    //对新题库的表进行存储 [卷面题型从mysql更换成oracle]
    //type为组卷类型，Q_PAPER_TYPE为卷面类型
    val newQuesDf = sqlContext.sql(
      s"select question_id, q_paper_type paper_type, difficult,type,if(state = 0,1,2) state,c_time from ex_exam_question_info_oracle where  is_del is null"
    ).selectExpr(
      "question_id",
      "realQuesId(question_id) real_ques_id",
      "paper_type",
      "difficult",
      "type","state status"
    ).cache()

    //昨天的数据跟昨天的数据进行比较，差值写入es
    val lastQuesOraDF = sqlContext.sql(s"select question_id,real_ques_id,paper_type,difficult,type,status from ques_oracle_defend")
    //昨天有修改的部分
    val newQuesDF = newQuesDf.except(lastQuesOraDF).cache()

    //大数据分析产生的试题难度以及正确率属性
    val quesCttDiffDF = sqlContext.sql("select question_id real_ques_id,cttdiff,right_rate,hot_option from tol_j_question_diff_info").cache()

    //大数据分析产生的试题标准时长
    val quesTimeDF = sqlContext.sql("select question_id real_ques_id, standard_time from bd_ques_standard_time_new").cache()

    //计算试题学段信息[小学，初中，高中]
    val paperType = sqlContext.sql("select school_type_id, p_type_id paper_type from tol_q_paper_type_info_oracle where is_del is null")

    val finalSchoolTypeDF = newQuesDF.join(paperType,"paper_type").selectExpr("question_id","school_type_id")


    //试题属性为年份，学段,选项,卷面题型，来源信息以及大数据产生的试题难度，正确率以及标准时长
    val newQuesBodyDF = newQuesDF.join(
      quesCttDiffDF,Seq("real_ques_id"),"left"
    ).join(
      quesTimeDF,Seq("real_ques_id"),"left"
    ).join(
      finalSchoolTypeDF,Seq("question_id"),"left"
    ).selectExpr(
      "question_id id",
      "question_id",
      "difficult",
      "cttdiff",
      "right_rate",
      "standard_time",
      "school_type_id",
//      "bodys",
      "paper_type paper_type_id",
      "type",
      "hot_option","status"
    ).cache()


    //将试题的难度，正确率，标准时长，学段，试题内容，卷面题型以及易错项进行存储
//    newQuesBodyDF.repartition(16).saveToEs(s"new_ques_all_profile_w/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
    newQuesBodyDF.repartition(16).saveToEs(s"test_ques_profile/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))


    //body不存储至hbase
    newQuesBodyDF.rdd.map(x => {
      val id = x.get(1).toString
      val diff = x.get(2).toString

      val put = new Put(id.getBytes)
      put.addColumn("tol".getBytes(),"diff".getBytes(),diff.getBytes())
      if(x.get(3) != null){
        put.addColumn("tol".getBytes(),"cttdiff".getBytes(),x.get(3).toString.getBytes())
      }
      if(x.get(4) != null){
        put.addColumn("tol".getBytes(),"rRate".getBytes(),x.get(4).toString.getBytes())
      }
      if(x.get(5) != null){
        put.addColumn("tol".getBytes(),"sTime".getBytes(),x.get(5).toString.getBytes())
      }
      if(x.get(6) != null){
        put.addColumn("tol".getBytes(),"sType".getBytes(),x.get(6).toString.getBytes())
      }
      if(x.get(7) != null){
        put.addColumn("tol".getBytes(),"pType".getBytes(),x.get(7).toString.getBytes())
      }
      if(x.get(8) != null){
        put.addColumn("tol".getBytes(),"type".getBytes(),x.get(8).toString.getBytes())
      }
      if(x.get(9) != null){
        put.addColumn("tol".getBytes(),"hotOP".getBytes(),x.get(9).toString.getBytes())
      }
      if(x.get(10) != null){
        put.addColumn("tol".getBytes(),"status".getBytes(),x.get(10).toString.getBytes())
      }

      (new  ImmutableBytesWritable(),put)
    }).saveAsNewAPIHadoopDataset(job.getConfiguration)

    //将oracle新题库的表存储至hive
    newQuesDf.selectExpr(
      "question_id", "real_ques_id", "paper_type", "difficult", "type","status"
    ).repartition(4).write.mode(SaveMode.Overwrite).format("orc").saveAsTable("ques_oracle_defend")


    //将年份转换成年的形式，期末的统一为后面的年份
    def calYear(exam_year:String,exam_type:Long,term_id:Long)={
      var year = 0
      val ex_year = exam_year.split("-")
      if (exam_type != 6){
        if(term_id==1)
          year=ex_year(0).toInt
        else year =ex_year(1).toInt
      }
      else
        year=ex_year(1).toInt
      year
    }
    sqlContext.udf.register("calYear",calYear _)
    //计算试题最大年份，来源 [成卷表与试题试卷连接表相关联]
    //school_id为199的是四中的题型
    val paperInfoDF = sqlContext.sql(
      "select test_paper_id, exam_year, province_id, city_id, exam_type,school_id,term_id,c_time from ex_exam_paper_info_oracle where is_del is null"
    ).selectExpr(
      "test_paper_id",
      "exam_year",
//      "province_id",
//      "city_id",
      "concat_ws(',',c_time,province_id,city_id) c_id",
      "exam_type",
      "school_id",
      "term_id",
      "calYear(exam_year,exam_type,term_id) year"
    )
    val sizhongDF = paperInfoDF.filter("school_id = 199").selectExpr("test_paper_id","school_id sizhong_type")
    val jPaperInfoDF = sqlContext.sql("select test_paper_id, question_id from ex_exam_j_paper_question_oracle where is_del is null").join(
      sizhongDF,Seq("test_paper_id"),"left"
    ).selectExpr("test_paper_id","question_id","sizhong_type")


    //增加程序的健壮性，避免出现["4_199","5_199","6","10"]有重复的情况
//    def disString(list:Seq[String])={
//      val str = list.mkString("_")
//      str.split("_").distinct.toList.sortBy(x => x.toInt).mkString(",")
//    }
//    sqlContext.udf.register("disString",disString _)

    //年份权重：最近两年的算2，最近四年又小于两年的算1，其他为0
    def getYearValue(year: String)={
      val thisYear = LocalDate.now().getYear
      if (year != null && year.length >= 5) {
        val thatyear = year.substring(0, 4).toInt
        if ((thisYear - thatyear) <= 2)
          2
        else if ((thisYear - thatyear) > 2 && (thisYear - thatyear) <= 4)
          1
        else
          0
      }
      else
        0
    }
    sqlContext.udf.register("getYearValue",getYearValue _)

    // 区域权重： 有城市的为1，没有城市有省份的为0.5，都没有的为0
    def getAreaValue(city:String, provide:String) ={
      if (city != null)
        1.0
      else if(city == null && provide != null)
        0.5
      else
        0.0
    }
    sqlContext.udf.register("getAreaValue",getAreaValue _)

    val examYearQuesDF = paperInfoDF.join(jPaperInfoDF,"test_paper_id").groupBy("question_id").agg(
      max("exam_year").as("ques_year"),
      max("c_id").as("c_id"),
//      max("province_id").as("province_id"),
      max("year").as("year"),
      max("term_id").as("term_id"),
      max("exam_type").as("exam_type"),
      max("sizhong_type").as("sizhong_type")
    ).selectExpr(
      "question_id", "ques_year", "year", "term_id",
      "split(c_id,',')[1] province_id",
      "split(c_id,',')[2] city_id",
//      "cast(city_id as string) city_id",
//      "cast(province_id as string) province_id",
      "exam_type","sizhong_type"
    ).selectExpr(
      "question_id id",
      "question_id",
      "ques_year",
      "year",
      "term_id",
      "cast(city_id as long) city_id",
      "cast(province_id as long) province_id",
      "exam_type",
      "getAreaValue(city_id,province_id) area_value",
      "getYearValue(ques_year) year_value","sizhong_type"
    ).cache()

    //将试题年份，处理过的年份，学期，城市，省份，来源, 年权重，地域权重
//    examYearQuesDF.repartition(16).saveToEs(s"new_ques_all_profile_w/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
    examYearQuesDF.repartition(16).saveToEs(s"test_ques_profile/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))

    examYearQuesDF.rdd.map(x => {
      val id = x.get(1).toString
      val quesYear = x.get(2).toString
      val year = x.get(3).toString
      val termId = x.get(4).toString
      val examType = x.get(7).toString
      val areaValue = x.get(8).toString
      val yearValue = x.get(9).toString

      val put = new Put(id.getBytes)
      put.addColumn("tol".getBytes(),"qYear".getBytes(),quesYear.getBytes())
      put.addColumn("tol".getBytes(),"year".getBytes(),year.getBytes())
      put.addColumn("tol".getBytes(),"termId".getBytes(),termId.getBytes())
      if (x.get(5) != null){
        put.addColumn("tol".getBytes(),"cityId".getBytes(),x.get(5).toString.getBytes())
      }
      if (x.get(6) != null){
        put.addColumn("tol".getBytes(),"proviId".getBytes(),x.get(6).toString.getBytes())
      }
      put.addColumn("tol".getBytes(),"examType".getBytes(),examType.getBytes())
      put.addColumn("tol".getBytes(),"areaValue".getBytes(),areaValue.getBytes())
      put.addColumn("tol".getBytes(),"yearValue".getBytes(),yearValue.getBytes())
      if (x.get(10) != null){
        put.addColumn("tol".getBytes(),"sizhong".getBytes(),x.get(10).toString.getBytes())
      }
      (new  ImmutableBytesWritable(),put)
    }).saveAsNewAPIHadoopDataset(job.getConfiguration)


    // 老师的试题收藏量
    val collectCountDF = sqlContext.sql("select user_id, question_id from user_question_collect_info_mysql").groupBy("question_id").agg(
      count("user_id").as("collect_count")
    ).selectExpr(
      "question_id id",
      "question_id",
      "collect_count"
    ).cache()

//    collectCountDF.repartition(16).saveToEs(s"new_ques_all_profile_w/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
    collectCountDF.repartition(16).saveToEs(s"test_ques_profile/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))

    collectCountDF.rdd.map(x => {
      val id = x.get(1).toString
      val collCount = x.get(2).toString

      val put = new Put(id.getBytes)
      put.addColumn("tol".getBytes(),"collCount".getBytes(),collCount.getBytes())
      (new  ImmutableBytesWritable(),put)
    }).saveAsNewAPIHadoopDataset(job.getConfiguration)

    //新知识体系下的所有试题对应的知识点 local_status=1为正常，local_status=2为删除
    //其他程序对这块专门进行处理了course_id > 0 新旧知识体系都包括
    val newPointNameDF = sqlContext.sql(
      "select course_id point_id,course_name point_name from tp_course_info_mysql where local_status=1"
    )

    val quesInfoDF = sqlContext.sql("select question_id,status from question_info_mysql where question_type<7").selectExpr(
      "question_id","if(status =1,status,2) status"
    )
    val newQuesPointDf = sqlContext.sql(
      "select course_id point_id,question_id from tp_j_course_question_info_mysql where course_id >0"
    ).join(newPointNameDF,"point_id").join(quesInfoDF,"question_id").selectExpr(
       "question_id","point_id","point_name","status").cache()

    //昨天的数据跟昨天的数据进行比较，差值写入es
    val lastQuesDF = sqlContext.sql(s"select question_id,point_id,point_name,status from ques_point_defend")
    //昨天有修改的部分
    val newQuesPointDF = newQuesPointDf.except(lastQuesDF)

    //新知识体系下找教材id，教材名称，学科，版本，年级
    val teachMaterialDF = sqlContext.sql("select course_id point_id,teaching_material_id material_id from tp_j_course_teaching_material_mysql")
    val materialGradeDF = sqlContext.sql("select material_id,grade_id,subject_id,version_id from teaching_material_info_mysql")
    val newPointQuesInfoDF = teachMaterialDF.join(
      materialGradeDF,"material_id"
    ).join(
      newQuesPointDF,"point_id"
    ).groupBy("question_id","status").agg(
      collect_set("material_id").as("material_ids"),
      collect_set("version_id").as("version_ids"),
      collect_set("grade_id").as("grade_ids"),
      collect_set("point_id").as("point_ids"),
      collect_set("point_name").as("point_names"),
      max("subject_id").as("subject_id")
    ).selectExpr(
      "question_id id",
      "question_id",
      "material_ids",
      "version_ids",
      "grade_ids",
      "point_ids",
      "point_names",
      "subject_id",
      "status"
    ).cache()


    //    newPointQuesInfoDF.repartition(16).saveToEs(s"new_ques_all_profile_w/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
    newPointQuesInfoDF.repartition(16).saveToEs(s"test_ques_profile/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))

    newPointQuesInfoDF.selectExpr(
      "question_id id",
      "question_id",
      "mkString(material_ids) material_ids",
      "mkString(version_ids) version_ids",
      "mkString(grade_ids) grade_ids",
      "mkString(point_ids) point_ids",
      "mkString(point_names) point_names",
      "subject_id",
      "status"
    ).rdd.map(x => {
      val id = x.get(1).toString
      val materIds = x.get(2).toString
      val verIds = x.get(3).toString
      val gradeIds = x.get(4).toString
      val pointIds = x.get(5).toString
      val pointNames = x.get(6).toString
      val subIds = x.get(7).toString
      val status = x.get(8).toString

      val put = new Put(id.getBytes)
      put.addColumn("tol".getBytes(),"materIds".getBytes(),materIds.getBytes())
      put.addColumn("tol".getBytes(),"verIds".getBytes(),verIds.getBytes())
      put.addColumn("tol".getBytes(),"gradeIds".getBytes(),gradeIds.getBytes())
      put.addColumn("tol".getBytes(),"pointIds".getBytes(),pointIds.getBytes())
      put.addColumn("tol".getBytes(),"pointNames".getBytes(),pointNames.getBytes())
      put.addColumn("tol".getBytes(),"subIds".getBytes(),subIds.getBytes())
      put.addColumn("tol".getBytes(),"status".getBytes(),status.getBytes())
      (new  ImmutableBytesWritable(),put)
    }).saveAsNewAPIHadoopDataset(job.getConfiguration)

    //将昨天的数据写入hive
    newQuesPointDf.selectExpr(
      "question_id","point_id","point_name","status"
    ).repartition(4).write.mode(SaveMode.Overwrite).format("orc").saveAsTable("ques_point_defend")


    //使用量权重：为null的权重为0，使用量小于3的为0.5，大于3的为1
    def useValue(use:String)={
      if(use == null)
        0.0
      else if(use < "3")
        0.5
      else
        1.0
    }
    sqlContext.udf.register("useValue",useValue _)
    //计算试题使用量[老师布置]
    //task_type = 3为单题测试，task_type = 4为成卷测试,task_type = 6为微视频
    val taskQuesDF = sqlContext.sql("select task_id,task_value_id,paper_id,task_type from tp_task_info_mysql where task_type in(3,4,6)")

    val singleQuesDF = taskQuesDF.filter("task_type = 3").selectExpr("task_id","task_value_id question_id")

    val paperTaskDF = taskQuesDF.filter("task_type = 4").selectExpr("task_id", "task_value_id paper_id")

    val videoTaskDF = taskQuesDF.filter("task_type = 6").selectExpr("task_id", "paper_id")

    val paperQuesDF = sqlContext.sql("select paper_id, question_id from j_paper_question_mysql")

    val allTaskQuesDF = paperTaskDF.unionAll(videoTaskDF).join(paperQuesDF,"paper_id").selectExpr(
      "task_id","question_id"
    ).unionAll(singleQuesDF).groupBy("question_id").agg(count("task_id").as("use_count")).selectExpr(
      "question_id",
      "cast(use_count as string) use_count"
    ).selectExpr(
      "question_id id",
      "question_id",
      "use_count",
      "useValue(use_count) use_value"
    ).cache()

//    allTaskQuesDF.repartition(16).saveToEs(s"new_ques_all_profile_w/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
    allTaskQuesDF.repartition(16).saveToEs(s"test_ques_profile/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))

    allTaskQuesDF.rdd.map(x => {
      val id = x.get(1).toString
      val useCount = x.get(2).toString
      val useValue = x.get(3).toString

      val put = new Put(id.getBytes)
      put.addColumn("tol".getBytes(),"useCount".getBytes(),useCount.getBytes())
      put.addColumn("tol".getBytes(),"useValue".getBytes(),useValue.getBytes())
      (new  ImmutableBytesWritable(),put)
    }).saveAsNewAPIHadoopDataset(job.getConfiguration)

    //添加旧题中的内容，试题类型，卷面类型，考试年份，省份，城市，试题难度，考试类型
    val cityIdDF = sqlContext.sql("select city_id, city_name city from city_info_mysql")
    val provinIdDF = sqlContext.sql("select province_id,province_name province from province_info_mysql")

    val oldQuesDf = sqlContext.sql(
      "select question_id,content,question_type,exam_year,province,city,question_difficulty difficult,paper_type_id,analysis,if(status=1,status,2) status from question_info_mysql"
    ).join(cityIdDF,Seq("city"),"left").join(provinIdDF,Seq("province"),"left").selectExpr(
      "question_id",
      "realQuesId(question_id) real_ques_id",
      "question_type type",
      "paper_type_id",
      "exam_year","province_id","city_id","difficult",
      "concat_ws(',',content,analysis) content","status"
    )

    //求昨天和前天的数据变化的差值
    val lastOldQues = sqlContext.sql(
      s"select question_id,real_ques_id,type,paper_type_id,exam_year,province_id,city_id,difficult,content,status from old_ques_defend"
    )

    val oldQuesDF  = oldQuesDf.except(lastOldQues)

    //对旧的试题查找试题选项信息
    val quesOldBodyDF = sqlContext.sql(
      "select question_id,content option_body from j_question_option_mysql"
    ).groupBy("question_id").agg(collect_list("option_body").as("option_bodys")).selectExpr(
      "question_id",
      "mkString(option_bodys) option_bodys"
    )

    val quesOldAllDF = oldQuesDF.join(quesOldBodyDF,Seq("question_id"),"left").selectExpr(
      "question_id",
      "real_ques_id",
      "type",
      "paper_type_id",
      "exam_year","province_id","city_id","difficult",
      "concat_ws(',',content,option_bodys) bodys","status"
    ).cache()

    //试题组以及组试题的试题的数据单独处理
    val quesOldTeamIdDF = quesOldAllDF.filter("type = 6").selectExpr(
      "question_id team_id",
      "real_ques_id", "type",
      "paper_type_id",
      "exam_year","province_id","city_id","difficult", "bodys","status"
    )
    val teamOldQuesIdDF = quesOldAllDF.filter("type >=7").selectExpr(
      "question_id",
      "bodys ques_body"
    )

    //试题组和组试题的关系
    val relationOldDF = sqlContext.sql("select team_id, ques_id question_id from j_ques_team_rela_mysql")

    //将组试题的内容整合进试题组中，除去组试题的内容
    val oldQuesTeamDF = quesOldTeamIdDF.join(relationOldDF,"team_id").join(teamOldQuesIdDF,"question_id").selectExpr(
      "team_id",
      "real_ques_id","type",
      "paper_type_id",
      "exam_year","province_id","city_id","difficult",
      "concat_ws(',',bodys,ques_body) bodys","status"
    ).groupBy(
      "team_id", "real_ques_id", "type",
      "paper_type_id",
      "exam_year","province_id","city_id","difficult","status"
    ).agg(collect_list("bodys").as("bodys")).selectExpr(
      "team_id question_id",
      "real_ques_id",
      "type",
      "paper_type_id",
      "exam_year","province_id","city_id","difficult",
      "mkString(bodys) bodys","status"
    ).unionAll(
      quesOldAllDF.filter("type<6").select(
        "question_id","real_ques_id",
        "type",
        "paper_type_id",
        "exam_year","province_id","city_id","difficult",
        "bodys","status"))

    //旧知识试题属性为年份，选项,卷面题型，来源信息以及大数据产生的试题难度，正确率,标准时长以及易错项
    val oldQuesBodyDF = oldQuesTeamDF.join(
      quesCttDiffDF,Seq("real_ques_id"),"left"
    ).join(
      quesTimeDF,Seq("real_ques_id"),"left"
    ).selectExpr(
      "question_id id",
      "question_id",
//      "coalesce(cttdiff,difficult) difficult",
      "difficult",
      "cttdiff",
      "right_rate",
      "standard_time",
      "bodys",
      "paper_type_id",
      "hot_option","type","exam_year year","province_id","city_id","status"
    ).cache()

    val cityYearDF = oldQuesBodyDF.selectExpr(
      "question_id",
      "cast(city_id as string) city_id",
      "cast(province_id as string) province_id",
      "year"
    ).selectExpr(
      "question_id id",
      "question_id",
      "cast(city_id as long) city_id",
      "cast(province_id as long) province_id",
      "year",
      "getAreaValue(city_id,province_id) area_value",
      "getYearValue(year) year_value"
    ).cache()


    //    oldQuesBodyDF.repartition(16).saveToEs(s"new_ques_all_profile_w/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
//    cityIdDF.repartition(16).saveToEs(s"new_ques_all_profile_w/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
    oldQuesBodyDF.repartition(16).saveToEs(s"test_ques_profile/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
    cityYearDF.repartition(16).saveToEs(s"test_ques_profile/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))

    //去掉body的存储
    oldQuesBodyDF.rdd.map(x => {
      val id = x.get(1).toString
      val type1 = x.get(9).toString

      val put = new Put(id.getBytes)
      if (x.get(2) != null){
        put.addColumn("tol".getBytes(),"diff".getBytes(),x.get(2).toString.getBytes())
      }
      if (x.get(3) != null){
        put.addColumn("tol".getBytes(),"cttdiff".getBytes(),x.get(3).toString.getBytes())
      }
      if (x.get(4) != null){
        put.addColumn("tol".getBytes(),"rRate".getBytes(),x.get(4).toString.getBytes())
      }
      if(x.get(5) != null){
        put.addColumn("tol".getBytes(),"sTime".getBytes(),x.get(5).toString.getBytes())
      }
      if(x.get(7) != null){
        put.addColumn("tol".getBytes(),"pType".getBytes(),x.get(7).toString.getBytes())
      }
      if(x.get(8) != null){
        put.addColumn("tol".getBytes(),"hotOP".getBytes(),x.get(8).toString.getBytes())
      }
      if(x.get(9) != null){
        put.addColumn("tol".getBytes(),"type".getBytes(),x.get(9).toString.getBytes())
      }
      if(x.get(10) != null){
        put.addColumn("tol".getBytes(),"year".getBytes(),x.get(10).toString.getBytes())
      }
      if(x.get(11) != null){
        put.addColumn("tol".getBytes(),"proviId".getBytes(),x.get(11).toString.getBytes())
      }
      if(x.get(12) != null){
        put.addColumn("tol".getBytes(),"cityId".getBytes(),x.get(12).toString.getBytes())
      }
      if(x.get(13) != null){
        put.addColumn("tol".getBytes(),"status".getBytes(),x.get(13).toString.getBytes())
      }
      (new  ImmutableBytesWritable(),put)
    }).saveAsNewAPIHadoopDataset(job.getConfiguration)

    cityYearDF.rdd.map(x => {
      val id = x.get(1).toString
      val areaValue = x.get(5).toString
      val yearValue = x.get(6).toString

      val put = new Put(id.getBytes)
      put.addColumn("tol".getBytes(),"areaValue".getBytes(),areaValue.getBytes())
      put.addColumn("tol".getBytes(),"yearValue".getBytes(),yearValue.getBytes())
      (new  ImmutableBytesWritable(),put)
    }).saveAsNewAPIHadoopDataset(job.getConfiguration)

    //将昨天的数据进行保存至hive
    oldQuesDf.selectExpr(
      "question_id","real_ques_id","type","paper_type_id","exam_year","province_id","city_id","difficult","content","status"
    ).repartition(4).write.mode(SaveMode.Overwrite).format("orc").saveAsTable("old_ques_defend")


    //自建课下的手动添加的试题
    //从tp_j_course_ques_info 导入条件为 course_id <0 and is_quote = 0 的数据
    val buildOneself = sqlContext.sql("select course_id ,question_id from tp_j_course_question_info_mysql where course_id <0 and is_quote = 0")
//    val shareType = sqlContext.sql("select course_id, share_type from tp_course_info_mysql")
    val buildMaterDF = sqlContext.sql("select course_id,teaching_material_id build_mater_id from tp_j_course_teaching_material_mysql")

    def sortList(list:Seq[Long]) ={
      list.toList.sortWith(_ > _)
    }
    sqlContext.udf.register("sortList",sortList _)

    val buildShareDf = buildOneself.join(buildMaterDF,"course_id").join(quesInfoDF,"question_id").groupBy("question_id","status").agg(
      collect_set("course_id").as("course_ids"),
      collect_set("build_mater_id").as("build_mater_ids")
//      collect_set("share_type").as("share_types")
    ).selectExpr(
      "question_id",
      "sortList(course_ids) course_ids",
      "sortList(build_mater_ids) build_mater_ids",
      "status"
    ).selectExpr(
      "question_id","course_ids","build_mater_ids","status"
    ).cache()

    //求昨天和前天的数据变化的差值
    val lastbuildDF = sqlContext.sql(
      s"select question_id,sortList(course_ids) course_ids,sortList(build_mater_ids) build_mater_ids,status from build_ques_defend"
    )

    val buildShareDF = buildShareDf.except(lastbuildDF).selectExpr(
      "question_id id",
      "question_id",
      "course_ids",
      "status"
    )

   //    buildShareDF.repartition(16).saveToEs(s"new_ques_all_profile_w/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))
    buildShareDF.repartition(16).saveToEs(s"test_ques_profile/new_ques_all_profile",Map("es.mapping.id" -> "id","es.write.operation" -> "upsert"))

    buildShareDF.selectExpr(
      "question_id id",
      "question_id",
      "mkString(course_ids) course_ids"
    ).rdd.map(x => {
      val id = x.get(1).toString
      val courseId = x.get(2).toString

      val put = new Put(id.getBytes)
      put.addColumn("tol".getBytes(),"course_ids".getBytes(),courseId.getBytes())
      (new  ImmutableBytesWritable(),put)
    }).saveAsNewAPIHadoopDataset(job.getConfiguration)

    //将昨天的数据存储至hive表
    buildShareDf.selectExpr(
      "question_id", "course_ids", "build_mater_ids", "status"
    ).repartition(4).write.mode(SaveMode.Overwrite).format("orc").saveAsTable("build_ques_defend")


  }

}